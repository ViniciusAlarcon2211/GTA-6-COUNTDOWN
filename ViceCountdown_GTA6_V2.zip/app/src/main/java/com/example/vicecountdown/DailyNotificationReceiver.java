package com.example.vicecountdown;
import android.app.*; import android.content.*; import java.util.*;
public class DailyNotificationReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i) {
  String[] msgs={"Bom dia, seu merdinha. O GTA VI ainda está chegando.","🌴 Vice City te espera. Mais um dia no countdown.","🚗 Mais um dia sobrevivido. O lançamento está chegando.","☀️ Bom dia! A contagem continua.","🔥 Hoje estamos um dia mais perto de GTA VI.","🎮 Seu lembrete diário: ainda tem countdown pela frente.","🌴 A cidade está esperando. Confira quantos dias faltam."};
  String msg=msgs[new Random().nextInt(msgs.length)];
  NotificationCompat.Builder b=new NotificationCompat.Builder(c,"daily").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("VI • COUNTDOWN").setContentText(msg).setStyle(new NotificationCompat.BigTextStyle().bigText(msg)).setAutoCancel(true);
  ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(42,b.build());
 }
}