package com.example.vicecountdown;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import androidx.core.app.NotificationCompat;

public class MainActivity extends Activity {
    static final String PREFS="prefs";
    static final String CHANNEL="daily";
    final long LAUNCH = new GregorianCalendar(2026, Calendar.NOVEMBER, 19, 0, 0, 0).getTimeInMillis();
    TextView days,hours,mins,secs;
    Handler handler=new Handler();
    Runnable ticker;

    int pink=Color.rgb(255,70,180), purple=Color.rgb(125,70,255), cyan=Color.rgb(70,220,255);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        createChannel();
        if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 10);
        showHome();
    }

    TextView tv(String text,float size,int color) {
        TextView t=new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        t.setGravity(Gravity.CENTER);
        t.setPadding(8,8,8,8);
        return t;
    }

    LinearLayout base() {
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(24,26,24,24);
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setBackgroundColor(Color.rgb(9,6,24));
        return l;
    }

    Button btn(String text) {
        Button b=new Button(this); b.setText(text); b.setTextColor(Color.WHITE);
        b.setTextSize(14); b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(34,20,70));
        return b;
    }

    TextView card(String value,String label) {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER);
        box.setPadding(8,12,8,12); box.setBackgroundColor(Color.rgb(25,16,50));
        TextView v=tv(value,27,Color.WHITE), lab=tv(label,11,Color.LTGRAY);
        box.addView(v,new LinearLayout.LayoutParams(-1,0,1)); box.addView(lab);
        return v;
    }

    void showHome() {
        LinearLayout root=base();
        TextView brand=tv("GRAND THEFT AUTO",15,pink);
        root.addView(brand,new LinearLayout.LayoutParams(-1,55));
        TextView vi=tv("VI",92,Color.WHITE);
        vi.setTypeface(Typeface.create("sans-serif",Typeface.BOLD_ITALIC));
        root.addView(vi,new LinearLayout.LayoutParams(-1,125));
        TextView vice=tv("VICE CITY • COUNTDOWN",14,cyan);
        root.addView(vice,new LinearLayout.LayoutParams(-1,45));

        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.HORIZONTAL);
        days=card("—","DIAS"); hours=card("—","HORAS"); mins=card("—","MIN"); secs=card("—","SEG");
        TextView[] vs={days,hours,mins,secs};
        for(TextView v:vs) {
            LinearLayout p=(LinearLayout)v.getParent();
            grid.addView(p,new LinearLayout.LayoutParams(0,110,1));
        }
        root.addView(grid,new LinearLayout.LayoutParams(-1,125));
        root.addView(tv("19 • 11 • 2026",15,Color.WHITE),new LinearLayout.LayoutParams(-1,50));

        TextView quote=tv("A cidade está esperando.",17,Color.LTGRAY);
        root.addView(quote,new LinearLayout.LayoutParams(-1,60));

        Button settings=btn("⚙  CONFIGURAÇÕES");
        settings.setOnClickListener(v->showSettings());
        root.addView(settings,new LinearLayout.LayoutParams(-1,58));

        setContentView(root);
        startTicker();
    }

    void startTicker() {
        if(ticker!=null) handler.removeCallbacks(ticker);
        ticker=()->{
            long d=LAUNCH-System.currentTimeMillis();
            if(d<0)d=0;
            long s=d/1000; long dd=s/86400; s%=86400; long hh=s/3600; s%=3600; long mm=s/60; s%=60;
            days.setText(String.valueOf(dd)); hours.setText(String.format(Locale.US,"%02d",hh));
            mins.setText(String.format(Locale.US,"%02d",mm)); secs.setText(String.format(Locale.US,"%02d",s));
            handler.postDelayed(ticker,1000);
        };
        handler.post(ticker);
    }

    void showSettings() {
        LinearLayout root=base();
        root.addView(tv("CONFIGURAÇÕES",30,Color.WHITE),new LinearLayout.LayoutParams(-1,80));
        root.addView(tv("PERSONALIZE SUA EXPERIÊNCIA",13,pink),new LinearLayout.LayoutParams(-1,45));

        SharedPreferences p=getSharedPreferences(PREFS,0);
        Switch daily=new Switch(this); daily.setText("🔔  Notificação diária"); daily.setTextColor(Color.WHITE); daily.setTextSize(17);
        daily.setChecked(p.getBoolean("daily",true));
        root.addView(daily,new LinearLayout.LayoutParams(-1,65));

        TextView time=tv("Horário: "+p.getInt("hour",9)+":00",16,Color.WHITE);
        root.addView(time,new LinearLayout.LayoutParams(-1,60));
        Button change=btn("🕘 Alterar horário");
        change.setOnClickListener(v->pickTime(time,p));
        root.addView(change,new LinearLayout.LayoutParams(-1,58));

        root.addView(tv("MARCADOS",18,cyan),new LinearLayout.LayoutParams(-1,55));
        String[] marks={"100 dias","50 dias","30 dias","10 dias","7 dias","3 dias","1 dia","LANÇAMENTO"};
        for(String x:marks) {
            CheckBox c=new CheckBox(this); c.setText("  "+x); c.setTextColor(Color.LTGRAY);
            c.setChecked(p.getBoolean("mark_"+x,false));
            c.setOnCheckedChangeListener((b,checked)->p.edit().putBoolean("mark_"+x,checked).apply());
            root.addView(c,new LinearLayout.LayoutParams(-1,43));
        }

        Button save=btn("💾  SALVAR");
        save.setOnClickListener(v->{
            p.edit().putBoolean("daily",daily.isChecked()).apply();
            scheduleDaily();
            Toast.makeText(this,"Configurações salvas.",Toast.LENGTH_SHORT).show();
        });
        root.addView(save,new LinearLayout.LayoutParams(-1,58));

        Button back=btn("← VOLTAR");
        back.setOnClickListener(v->showHome());
        root.addView(back,new LinearLayout.LayoutParams(-1,58));
        setContentView(root);
    }

    void pickTime(TextView label,SharedPreferences p) {
        TimePickerDialog d=new TimePickerDialog(this,(view,h,m)->{
            p.edit().putInt("hour",h).putInt("minute",m).apply();
            label.setText(String.format(Locale.US,"Horário: %02d:%02d",h,m));
        },p.getInt("hour",9),p.getInt("minute",0),true);
        d.show();
    }

    void createChannel() {
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel c=new NotificationChannel(CHANNEL,"Countdown diário",NotificationManager.IMPORTANCE_DEFAULT);
            c.setDescription("Mensagens diárias do countdown");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    void scheduleDaily() {
        SharedPreferences p=getSharedPreferences(PREFS,0);
        if(!p.getBoolean("daily",true)) return;
        Intent i=new Intent(this, DailyNotificationReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,p.getInt("hour",9)); c.set(Calendar.MINUTE,p.getInt("minute",0)); c.set(Calendar.SECOND,0);
        if(c.getTimeInMillis()<=System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR,1);
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
    }
}