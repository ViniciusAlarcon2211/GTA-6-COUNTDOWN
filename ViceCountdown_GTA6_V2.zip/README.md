# Vice Countdown — Android
Cronômetro profissional para o lançamento de GTA VI, com estética neon inspirada em Vice City.
Data configurada: 19 de novembro de 2026.
O projeto usa Android nativo e não depende de bibliotecas externas.
Para gerar o APK: abra no Android Studio e use Build > Build APK(s).
