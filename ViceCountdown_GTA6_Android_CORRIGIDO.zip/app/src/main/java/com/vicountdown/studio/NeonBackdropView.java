package com.vicountdown.studio;
import android.graphics.*;
import android.view.View;
import android.content.Context;
import android.graphics.LinearGradient;
import android.graphics.Shader;

public class NeonBackdropView extends View {
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    public NeonBackdropView(Context c){super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    @Override protected void onDraw(Canvas c){
        int w=getWidth(), h=getHeight();
        LinearGradient g=new LinearGradient(0,0,w,h,new int[]{Color.rgb(5,4,20),Color.rgb(29,9,57),Color.rgb(4,24,48)},null,Shader.TileMode.CLAMP);
        p.setShader(g); c.drawRect(0,0,w,h,p); p.setShader(null);

        // moon/sun glow
        p.setColor(Color.argb(55,255,105,185)); p.setShadowLayer(60,0,0,Color.rgb(255,70,180));
        c.drawCircle(w*0.72f,h*0.24f,62,p); p.clearShadowLayer();
        p.setColor(Color.argb(210,255,170,90)); c.drawCircle(w*0.72f,h*0.24f,28,p);

        // horizon glow
        LinearGradient hg=new LinearGradient(0,h*.54f,0,h*.72f,
            Color.TRANSPARENT,Color.argb(90,255,67,180),Shader.TileMode.CLAMP);
        p.setShader(hg); c.drawRect(0,h*.50f,w,h*.74f,p); p.setShader(null);

        // distant buildings
        p.setColor(Color.argb(220,8,7,24));
        for(int i=0;i<14;i++){
            float bw=28+(i%4)*12, bh=55+(i*23%100);
            float x=i*w/14f-bw/2;
            c.drawRect(x,h*.72f-bh,x+bw,h*.72f,p);
            p.setColor(Color.argb(80,255,185,100));
            for(int j=0;j<3;j++) c.drawRect(x+5+j*7,h*.72f-bh+12+j*12,x+9+j*7,h*.72f-bh+16+j*12,p);
            p.setColor(Color.argb(220,8,7,24));
        }

        // road
        p.setColor(Color.argb(245,4,4,15)); c.drawRect(0,h*.72f,w,h,p);
        p.setColor(Color.argb(100,255,65,180));
        for(int i=0;i<7;i++){float y=h*.76f+i*h*.035f; c.drawRect(w*.44f-i*18,y,w*.56f+i*18,y+3,p);}

        // palms
        drawPalm(c,w*.11f,h*.76f,1.0f);
        drawPalm(c,w*.88f,h*.76f,0.85f);
    }
    void drawPalm(Canvas c,float x,float y,float s){
        p.setColor(Color.argb(230,10,7,22)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(7*s);
        Path trunk=new Path(); trunk.moveTo(x,y); trunk.cubicTo(x-8*s,y-50*s,x+5*s,y-100*s,x+2*s,y-145*s); c.drawPath(trunk,p);
        p.setStyle(Paint.Style.FILL);
        float tx=x+2*s, ty=y-145*s;
        for(int i=0;i<8;i++){
            double a=Math.PI*2*i/8; Path leaf=new Path(); leaf.moveTo(tx,ty);
            leaf.quadTo(tx+(float)Math.cos(a-.25)*45*s,ty+(float)Math.sin(a-.25)*35*s,tx+(float)Math.cos(a)*70*s,ty+(float)Math.sin(a)*20*s);
            leaf.quadTo(tx+(float)Math.cos(a+.25)*45*s,ty+(float)Math.sin(a+.25)*35*s,tx,ty); c.drawPath(leaf,p);
        }
    }
}
