package com.vicountdown.app;

import android.Manifest;
import android.app.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import com.vicountdown.app.countdown.CountdownEngine;
import com.vicountdown.app.data.AppPrefs;
import com.vicountdown.app.messages.MessageRepository;
import com.vicountdown.app.notifications.NotificationHelper;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private FrameLayout content;
    private AppPrefs prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable ticker;
    private ActivityResultLauncher<String> permissionLauncher;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);
        prefs = new AppPrefs(this);
        content = findViewById(R.id.content);
        permissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) NotificationHelper.schedule(this);
        });
        showHome();
        View splash=findViewById(R.id.splash);
        splash.setAlpha(1f);
        handler.postDelayed(() -> splash.animate().alpha(0f).setDuration(380).withEndAction(() -> splash.setVisibility(View.GONE)).start(), 850);
    }

    private void showHome() {
        stopTicker();
        View v = getLayoutInflater().inflate(R.layout.view_home, content, false);
        content.removeAllViews(); content.addView(v);
        TextView days=v.findViewById(R.id.days), hours=v.findViewById(R.id.hours), minutes=v.findViewById(R.id.minutes), seconds=v.findViewById(R.id.seconds);
        TextView tagline=v.findViewById(R.id.tagline), daily=v.findViewById(R.id.dailyMessage), date=v.findViewById(R.id.releaseDate), progressLabel=v.findViewById(R.id.progressLabel);
        ProgressBar progress=v.findViewById(R.id.progress);
        TextView menu=v.findViewById(R.id.menuButton);
        applySafeInsets(v.findViewById(R.id.safeContent));
        View drawerOverlay=v.findViewById(R.id.drawerOverlay), drawer=v.findViewById(R.id.drawer);
        applySafeInsets(v.findViewById(R.id.drawerSafe));
        daily.setText(MessageRepository.daily());
        date.setText("VICE CITY  •  19 NOV 2026  •  LANÇAMENTO");
        progress.setVisibility(prefs.showProgress()?View.VISIBLE:View.GONE);
        progress.setProgress(CountdownEngine.progress1000());
        progressLabel.setText((CountdownEngine.progress1000()/10)+"% DA ESPERA");
        menu.setOnClickListener(anchor -> { drawerOverlay.setVisibility(View.VISIBLE); drawer.setTranslationX(-dp(320)); drawer.animate().translationX(0).setDuration(240).start(); });
        drawerOverlay.setOnClickListener(x -> drawerOverlay.setVisibility(View.GONE));
        drawer.setOnClickListener(x -> {});
        v.findViewById(R.id.menuHome).setOnClickListener(x -> showHome());
        v.findViewById(R.id.menuMessages).setOnClickListener(x -> showMessages());
        v.findViewById(R.id.menuMilestones).setOnClickListener(x -> showMessages());
        v.findViewById(R.id.menuSettings).setOnClickListener(x -> showSettings());
        v.findViewById(R.id.menuAbout).setOnClickListener(x -> showAbout());
        ticker=new Runnable(){ public void run(){
            CountdownEngine.Snapshot s=CountdownEngine.now();
            days.setText(String.valueOf(s.days())); hours.setText(String.format(Locale.getDefault(),"%02d",s.hours())); minutes.setText(String.format(Locale.getDefault(),"%02d",s.minutes())); seconds.setText(String.format(Locale.getDefault(),"%02d",s.seconds()));
            if(s.launched()){tagline.setText("A ESPERA TERMINOU");days.setText("VI");hours.setText("00");minutes.setText("00");seconds.setText("00");}
            handler.postDelayed(this,1000);
        }};
        handler.post(ticker); animateIn(v);
    }

    private void showMainMenu(View anchor){
        PopupMenu p=new PopupMenu(this,anchor);
        p.getMenu().add("Início"); p.getMenu().add("Mensagens"); p.getMenu().add("Marcos da contagem"); p.getMenu().add("Configurações"); p.getMenu().add("Sobre o aplicativo");
        p.setOnMenuItemClickListener(item->{String t=item.getTitle().toString(); if(t.equals("Mensagens")||t.equals("Marcos da contagem")) showMessages(); else if(t.equals("Configurações")) showSettings(); else if(t.equals("Sobre o aplicativo")) showAbout(); else showHome(); return true;});
        p.show();
    }

    private void showMessages(){
        stopTicker(); View v=getLayoutInflater().inflate(R.layout.view_messages,content,false); LinearLayout list=v.findViewById(R.id.messageList); applySafeInsets(v.findViewById(R.id.safeContent)); v.findViewById(R.id.backButton).setOnClickListener(x->showHome());
        for(MessageRepository.Item item:MessageRepository.all()){
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(16),dp(14),dp(16),dp(14)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(12));card.setLayoutParams(cp);card.setBackgroundResource(R.drawable.glass_panel);
            TextView meta=tv(item.category().toUpperCase()+"  •  "+item.date(),11,0xFFFF63C2); meta.setLetterSpacing(.10f); TextView body=tv(item.text(),17,0xFFFFFFFF);body.setPadding(0,dp(7),0,0);card.addView(meta);card.addView(body);list.addView(card);
        }
        content.removeAllViews();content.addView(v);animateIn(v);
    }

    private void showSettings(){
        stopTicker(); View v=getLayoutInflater().inflate(R.layout.view_settings,content,false); applySafeInsets(v.findViewById(R.id.safeContent)); v.findViewById(R.id.backButton).setOnClickListener(x->showHome());
        Switch notifications=v.findViewById(R.id.notifications),sound=v.findViewById(R.id.sound),vibration=v.findViewById(R.id.vibration),progress=v.findViewById(R.id.showProgress); Button time=v.findViewById(R.id.timeButton),test=v.findViewById(R.id.testNotification); Spinner theme=v.findViewById(R.id.themeSpinner),effect=v.findViewById(R.id.effectSpinner);
        notifications.setChecked(prefs.notifications());sound.setChecked(prefs.sound());vibration.setChecked(prefs.vibration());progress.setChecked(prefs.showProgress());updateTimeButton(time);
        theme.setAdapter(spinnerAdapter(new String[]{"Vice Night","Midnight","Sunset"}));effect.setAdapter(spinnerAdapter(new String[]{"Baixa","Média","Alta"}));theme.setSelection(prefs.theme());effect.setSelection(prefs.effect());
        notifications.setOnCheckedChangeListener((b,c)->{prefs.notifications(c);if(c&&Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);else NotificationHelper.schedule(this);});
        sound.setOnCheckedChangeListener((b,c)->prefs.sound(c));vibration.setOnCheckedChangeListener((b,c)->prefs.vibration(c));progress.setOnCheckedChangeListener((b,c)->prefs.showProgress(c));
        time.setOnClickListener(x->new TimePickerDialog(this,(picker,h,m)->{prefs.time(h,m);updateTimeButton(time);NotificationHelper.schedule(this);},prefs.hour(),prefs.minute(),true).show());
        test.setOnClickListener(x->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);else NotificationHelper.show(this,true);});
        theme.setOnItemSelectedListener(new SimpleSelection(i->prefs.theme(i)));effect.setOnItemSelectedListener(new SimpleSelection(i->prefs.effect(i)));
        content.removeAllViews();content.addView(v);animateIn(v);
    }

    private ArrayAdapter<String> spinnerAdapter(String[] a){ArrayAdapter<String>x=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,a);return x;}
    private void showAbout(){new AlertDialog.Builder(this).setTitle("VI COUNTDOWN").setMessage("The Wait Is Almost Over\n\nProjeto independente, não oficial e feito por fã. Não é afiliado, endossado ou patrocinado pela Rockstar Games ou Take-Two Interactive.").setPositiveButton("FECHAR",null).show();}
    private void animateIn(View v){v.setAlpha(0f);v.setTranslationY(dp(8));v.animate().alpha(1f).translationY(0).setDuration(300).start();}
    private void updateTimeButton(Button b){b.setText(String.format(Locale.getDefault(),"HORÁRIO DA NOTIFICAÇÃO  •  %02d:%02d",prefs.hour(),prefs.minute()));}
    private TextView tv(String s,int sp,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);return t;}
    private void applySafeInsets(View v){
        final int baseTop=dp(8), baseBottom=dp(8);
        ViewCompat.setOnApplyWindowInsetsListener(v,(view,insets)->{androidx.core.graphics.Insets bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()); view.setPadding(view.getPaddingLeft(),baseTop+bars.top,view.getPaddingRight(),baseBottom+bars.bottom); return insets;});
        ViewCompat.requestApplyInsets(v);
    }
    private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+.5f);} private void stopTicker(){if(ticker!=null)handler.removeCallbacks(ticker);ticker=null;}
    @Override public void onBackPressed(){showHome();}
    @Override protected void onDestroy(){stopTicker();super.onDestroy();}
    private static class SimpleSelection implements AdapterView.OnItemSelectedListener{interface C{void call(int i);}private final C c;SimpleSelection(C c){this.c=c;}public void onItemSelected(AdapterView<?>p,View v,int pos,long id){c.call(pos);}public void onNothingSelected(AdapterView<?>p){}}
}
