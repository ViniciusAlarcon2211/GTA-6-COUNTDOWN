package com.example.gta6countdown;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.text.*;

public class MainActivity extends Activity {
    TextView days, hours, mins, secs, status;
    final long launch = new GregorianCalendar(2026, Calendar.NOVEMBER, 19, 0, 0, 0).getTimeInMillis();
    Handler handler = new Handler(Looper.getMainLooper());
    Runnable tick = new Runnable(){ public void run(){ update(); handler.postDelayed(this,1000); } };

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String s,float size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); if(bold)t.setTypeface(null,1); return t;
    }
    GradientDrawable box(){
        GradientDrawable g=new GradientDrawable(); g.setColor(Color.argb(80,255,255,255)); g.setCornerRadius(dp(18)); g.setStroke(dp(1),Color.argb(90,255,120,220)); return g;
    }
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setPadding(dp(18),dp(25),dp(18),dp(18)); root.setBackgroundResource(com.example.gta6countdown.R.drawable.bg);

        TextView top=tv("VICE COUNTDOWN",16,Color.rgb(255,190,235),true);
        root.addView(top,new LinearLayout.LayoutParams(-1,dp(35)));
        TextView title=tv("GRAND THEFT AUTO",31,Color.WHITE,true);
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(55)));
        TextView six=tv("VI",62,Color.rgb(255,105,190),true);
        root.addView(six,new LinearLayout.LayoutParams(-1,dp(75)));

        TextView date=tv("19  •  NOVEMBER  •  2026",15,Color.rgb(220,220,255),true);
        root.addView(date,new LinearLayout.LayoutParams(-1,dp(40)));

        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER); row.setOrientation(LinearLayout.HORIZONTAL);
        days=unit(row,"DIAS"); hours=unit(row,"HORAS"); mins=unit(row,"MIN"); secs=unit(row,"SEG");
        root.addView(row,new LinearLayout.LayoutParams(-1,dp(125)));

        status=tv("VICE CITY IS WAITING",13,Color.rgb(255,180,220),true);
        root.addView(status,new LinearLayout.LayoutParams(-1,dp(45)));

        TextView info=tv("CONTAGEM REGRESSIVA ATÉ O LANÇAMENTO",11,Color.LTGRAY,false);
        root.addView(info,new LinearLayout.LayoutParams(-1,dp(35)));

        setContentView(root); update(); handler.post(tick);
    }
    TextView unit(LinearLayout row,String label){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER);
        card.setBackground(box());
        TextView n=tv("00",27,Color.WHITE,true); TextView l=tv(label,10,Color.rgb(255,180,230),true);
        card.addView(n,new LinearLayout.LayoutParams(-1,dp(60))); card.addView(l,new LinearLayout.LayoutParams(-1,dp(35)));
        row.addView(card,new LinearLayout.LayoutParams(0,dp(105),1));
        LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)card.getLayoutParams(); p.setMargins(dp(4),0,dp(4),0); card.setLayoutParams(p);
        return n;
    }
    void update(){
        long d=launch-System.currentTimeMillis();
        if(d<=0){days.setText("00");hours.setText("00");mins.setText("00");secs.setText("00");status.setText("GTA VI JÁ ESTÁ AQUI");return;}
        long s=d/1000; long dd=s/86400; s%=86400; long hh=s/3600; s%=3600; long mm=s/60; long ss=s%60;
        days.setText(String.format(Locale.US,"%02d",dd)); hours.setText(String.format(Locale.US,"%02d",hh));
        mins.setText(String.format(Locale.US,"%02d",mm)); secs.setText(String.format(Locale.US,"%02d",ss));
    }
    @Override protected void onDestroy(){handler.removeCallbacks(tick);super.onDestroy();}
}