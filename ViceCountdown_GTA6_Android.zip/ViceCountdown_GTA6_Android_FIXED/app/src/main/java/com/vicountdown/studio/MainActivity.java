package com.vicountdown.studio;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    public static final long TARGET_MILLIS = new GregorianCalendar(2026, Calendar.NOVEMBER, 19, 0, 0, 0).getTimeInMillis();
    private static final int NOTIF_REQ = 701;
    private LinearLayout content;
    private TextView countdown, subCountdown;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable tick;
    private final int pink = Color.rgb(255,79,179), cyan = Color.rgb(67,232,255), white = Color.rgb(255,249,255), muted = Color.rgb(169,172,193);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,6,12));
        getWindow().setNavigationBarColor(Color.rgb(5,6,12));
        DailyNotificationReceiver.createChannel(this);
        buildShell();
        requestNotificationsIfNeeded();
        NotificationScheduler.schedule(this);
    }

    private void buildShell() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5,6,12));
        root.addView(new NeonBackdropView(this), new FrameLayout.LayoutParams(-1,-1));

        LinearLayout shell = new LinearLayout(this); shell.setOrientation(LinearLayout.VERTICAL);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(18),dp(8),dp(18),dp(12));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false); scroll.addView(content);
        shell.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        shell.addView(navBar(), new LinearLayout.LayoutParams(-1,dp(72)));
        root.addView(shell, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root); showHome();
    }

    private View navBar() {
        LinearLayout nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(10),dp(6),dp(10),dp(8)); nav.setBackgroundColor(0xF2080A13);
        String[] labels={"⌂\nINÍCIO","✦\nFRASES","⚙\nAJUSTES"};
        for(int i=0;i<3;i++){
            final int tab=i; TextView t=text(labels[i],11,i==0?white:muted); t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(4,4,4,4);
            t.setOnClickListener(v->{ if(tab==0)showHome(); else if(tab==1)showMessages(); else showSettings(); });
            nav.addView(t,new LinearLayout.LayoutParams(0,-1,1));
        }
        return nav;
    }

    private void showHome(){
        content.removeAllViews();
        TextView e=text("VI COUNTDOWN",12,cyan); e.setTypeface(Typeface.DEFAULT,Typeface.BOLD); content.addView(e,margin(0,dp(10),0,dp(3)));
        TextView title=text("LEONIDA\nIS LOADING",30,white); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); content.addView(title,margin(0,0,0,dp(5)));
        content.addView(text("19 NOV 2026  •  data configurada para a estreia",11,muted),margin(0,0,0,dp(16)));

        LinearLayout hero=panel(true); LinearLayout h=column(dp(20),dp(18),dp(20),dp(18));
        TextView tag=text("CONTAGEM PRINCIPAL",11,cyan); tag.setTypeface(Typeface.DEFAULT,Typeface.BOLD); h.addView(tag);
        countdown=text("—",48,white); countdown.setGravity(Gravity.CENTER); countdown.setTypeface(Typeface.DEFAULT,Typeface.BOLD); h.addView(countdown,margin(0,dp(4),0,0));
        subCountdown=text("até o próximo grande capítulo",13,muted); subCountdown.setGravity(Gravity.CENTER); h.addView(subCountdown);
        h.addView(progressBar(),margin(0,dp(18),0,dp(3)));
        TextView date=text("19 de novembro de 2026",12,white); date.setGravity(Gravity.CENTER); h.addView(date);
        hero.addView(h); content.addView(hero,margin(0,0,0,dp(14)));

        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statCard("DIAS", "dias restantes"),new LinearLayout.LayoutParams(0,dp(92),1)); stats.addView(new Space(this),new LinearLayout.LayoutParams(dp(10),1)); stats.addView(statCard("AO VIVO","atualiza a cada segundo"),new LinearLayout.LayoutParams(0,dp(92),1));
        content.addView(stats,margin(0,0,0,dp(14)));

        LinearLayout msg=panel(false); LinearLayout ml=column(dp(17),dp(16),dp(17),dp(16));
        TextView mt=text("📡  MENSAGEM DO DIA",11,pink); mt.setTypeface(Typeface.DEFAULT,Typeface.BOLD); ml.addView(mt);
        TextView body=text(Messages.messageForDay(Math.max(0,daysRemaining())),16,white); body.setTypeface(Typeface.DEFAULT,Typeface.BOLD); ml.addView(body,margin(0,dp(8),0,dp(5)));
        ml.addView(text("Uma mensagem diferente por dia para acompanhar a contagem.",11,muted)); msg.addView(ml); content.addView(msg,margin(0,0,0,dp(14)));

        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button n=button("NOTIFICAÇÕES",true); n.setOnClickListener(v->showSettings()); Button p=button("CENTRAL DE FRASES",false); p.setOnClickListener(v->showMessages());
        row.addView(n,new LinearLayout.LayoutParams(0,dp(52),1)); row.addView(new Space(this),new LinearLayout.LayoutParams(dp(9),1)); row.addView(p,new LinearLayout.LayoutParams(0,dp(52),1)); content.addView(row,margin(0,0,0,dp(14)));
        TextView foot=text("VI COUNTDOWN 5.0  •  fã-made  •  não oficial",10,muted); foot.setGravity(Gravity.CENTER); content.addView(foot,margin(0,dp(8),0,dp(22)));
        startTicker();
    }

    private View progressBar(){
        ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); p.setMax(100); p.setProgress(progressPercent());
        if(Build.VERSION.SDK_INT>=21)p.setProgressTintList(ColorStateList.valueOf(pink)); return p;
    }
    private int progressPercent(){ long now=System.currentTimeMillis(); long start=new GregorianCalendar(2025,Calendar.MAY,26).getTimeInMillis(); if(now<=start)return 0;if(now>=TARGET_MILLIS)return 100;return (int)Math.max(0,Math.min(100,((now-start)*100.0)/(TARGET_MILLIS-start))); }

    private View statCard(String big,String small){ LinearLayout c=panel(false); c.setGravity(Gravity.CENTER); TextView a=text(big,18,white);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);a.setGravity(Gravity.CENTER);c.addView(a);TextView b=text(small,10,muted);b.setGravity(Gravity.CENTER);c.addView(b);return c; }

    private void showMessages(){
        content.removeAllViews(); content.addView(text("CENTRAL DE FRASES",26,white),margin(0,dp(10),0,dp(3)));
        content.addView(text("Mensagens originais com clima de Leonida, Vice City e do universo GTA.",12,muted),margin(0,0,0,dp(16)));
        String[] sections={"GTA VI • LEONIDA","VICE CITY • NEON","LEGADO GTA"}; int[] starts={0,60,120}; int[] ends={60,120,Messages.ALL.length};
        for(int s=0;s<3;s++){ TextView head=text(sections[s],11,s==0?cyan:(s==1?pink:0xFFFFA45B));head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);content.addView(head,margin(0,dp(7),0,dp(8)));int count=0;for(int i=starts[s];i<ends[s]&&count<18;i++,count++){LinearLayout c=panel(false);TextView t=text("“"+Messages.ALL[i]+"”",14,white);t.setPadding(dp(15),dp(14),dp(15),dp(14));c.addView(t);content.addView(c,margin(0,0,0,dp(8)));}}
    }

    private void showSettings(){
        content.removeAllViews(); content.addView(text("AJUSTES",26,white),margin(0,dp(10),0,dp(3))); content.addView(text("Configure notificações, horários, som, vibração e estilo.",12,muted),margin(0,0,0,dp(15)));
        section("NOTIFICAÇÕES");
        Switch sw=switcher("Mensagem diária","Receba uma mensagem diferente todos os dias.");sw.setChecked(Prefs.enabled(this));sw.setOnCheckedChangeListener((b,v)->{Prefs.enabled(this,v);NotificationScheduler.schedule(this);});content.addView(settingRow(sw),margin(0,0,0,dp(8)));
        content.addView(text("Horário das mensagens",13,white),margin(0,dp(7),0,dp(5)));
        Button time=button(String.format(Locale.getDefault(),"TODOS OS DIAS • %02d:%02d",Prefs.hour(this),Prefs.minute(this)),false);time.setOnClickListener(v->pickTime(time));content.addView(time,margin(0,0,0,dp(8)));
        Button test=button("ENVIAR NOTIFICAÇÃO DE TESTE",true);test.setOnClickListener(v->{DailyNotificationReceiver.createChannel(this);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestNotificationsIfNeeded();return;}DailyNotificationReceiver.show(this);Toast.makeText(this,"Notificação enviada.",Toast.LENGTH_SHORT).show();});content.addView(test,margin(0,0,0,dp(10)));
        Switch sound=switcher("Som","Usar o som padrão da notificação.");sound.setChecked(Prefs.sound(this));sound.setOnCheckedChangeListener((b,v)->Prefs.sound(this,v));content.addView(settingRow(sound),margin(0,0,0,dp(8)));
        Switch vib=switcher("Vibração","Usar vibração curta ao notificar.");vib.setChecked(Prefs.vibration(this));vib.setOnCheckedChangeListener((b,v)->Prefs.vibration(this,v));content.addView(settingRow(vib),margin(0,0,0,dp(8)));
        section("MARCOS"); Switch milestones=switcher("Mensagens especiais","Destacar 180, 100, 60, 30, 14, 7, 3, 1 dia e hoje.");milestones.setChecked(Prefs.milestones(this));milestones.setOnCheckedChangeListener((b,v)->Prefs.milestones(this,v));content.addView(settingRow(milestones),margin(0,0,0,dp(8)));
        content.addView(text("Marcos ativos: 180 • 100 • 60 • 30 • 14 • 7 • 3 • 1 • HOJE",11,muted),margin(dp(14),0,0,dp(12)));
        section("ESTILO DAS MENSAGENS");
        RadioGroup rg=new RadioGroup(this);String[] labels={"MIX VICE CITY • LEONIDA","GTA VI • CIDADE / MAPA","LEGADO GTA • CLIMA CLÁSSICO","MOTIVAÇÃO / COUNTDOWN"};String[] vals={"mix","vi","legacy","motivation"};String saved=Prefs.style(this);
        for(int i=0;i<labels.length;i++){RadioButton rb=new RadioButton(this);rb.setText(labels[i]);rb.setTextColor(white);rb.setTextSize(13);rb.setTag(vals[i]);rb.setPadding(0,dp(5),0,dp(5));if(saved.equals(vals[i]))rb.setChecked(true);rg.addView(rb);}
        rg.setOnCheckedChangeListener((g,id)->{RadioButton rb=g.findViewById(id);if(rb!=null)Prefs.style(this,String.valueOf(rb.getTag()));});content.addView(rg,margin(0,0,0,dp(12)));
        section("APARÊNCIA");content.addView(text("Tema neon noturno • fundo animado • cards translúcidos • alto contraste",12,muted),margin(0,0,0,dp(12)));
        Button about=button("SOBRE O APP",false);about.setOnClickListener(v->showAbout());content.addView(about,margin(0,0,0,dp(20)));
    }

    private void showAbout(){content.removeAllViews();content.addView(text("SOBRE",26,white),margin(0,dp(10),0,dp(12)));LinearLayout c=panel(true);LinearLayout l=column(dp(20),dp(20),dp(20),dp(20));TextView a=text("VI COUNTDOWN 5.0",22,white);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);l.addView(a);l.addView(text("Um countdown fã-made inspirado na energia neon de Vice City e no universo de Grand Theft Auto. Não é um produto oficial da Rockstar Games.",13,muted),margin(0,dp(8),0,0));l.addView(text("Data configurada: 19 de novembro de 2026.",13,white),margin(0,dp(12),0,0));l.addView(text("As mensagens do app são originais.",12,muted),margin(0,dp(8),0,0));c.addView(l);content.addView(c);Button back=button("VOLTAR AO INÍCIO",true);back.setOnClickListener(v->showHome());content.addView(back,margin(0,dp(14),0,dp(20)));}

    private void section(String s){TextView t=text(s,11,cyan);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);content.addView(t,margin(0,dp(12),0,dp(8)));}
    private Switch switcher(String title,String summary){Switch s=new Switch(this);s.setText(title+"\n"+summary);s.setTextColor(white);s.setTextSize(13);s.setPadding(dp(14),dp(10),dp(8),dp(10));return s;}
    private View settingRow(View v){LinearLayout c=panel(false);c.addView(v,new LinearLayout.LayoutParams(-1,-2));return c;}
    private void pickTime(Button btn){TimePickerDialog d=new TimePickerDialog(this,(view,h,m)->{Prefs.time(this,h,m);btn.setText(String.format(Locale.getDefault(),"TODOS OS DIAS • %02d:%02d",h,m));NotificationScheduler.schedule(this);},Prefs.hour(this),Prefs.minute(this),true);d.show();}
    private void requestNotificationsIfNeeded(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIF_REQ);}

    private void startTicker(){if(tick!=null)handler.removeCallbacks(tick);tick=()->{if(countdown!=null){long diff=TARGET_MILLIS-System.currentTimeMillis();if(diff<=0){countdown.setText("É HOJE");subCountdown.setText("A contagem chegou ao destino.");}else{long sec=diff/1000;long days=sec/86400;sec%=86400;long hrs=sec/3600;sec%=3600;long min=sec/60;sec%=60;countdown.setText(String.format(Locale.getDefault(),"%03d",days));subCountdown.setText(String.format(Locale.getDefault(),"%02dh %02dm %02ds restantes",hrs,min,sec));}}handler.postDelayed(tick,1000);};handler.post(tick);}
    public static int daysRemaining(){long diff=TARGET_MILLIS-System.currentTimeMillis();return (int)Math.max(0,Math.ceil(diff/86400000.0));}

    private LinearLayout panel(boolean strong){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{strong?0xEE171B31:0xDD121629,strong?0xE814182B:0xCC0D1020});g.setCornerRadius(dp(strong?26:22));g.setStroke(dp(1),strong?0x6643E8FF:0x332F4770);l.setBackground(g);return l;}
    private LinearLayout column(int l,int t,int r,int b){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(l,t,r,b);return x;}
    private Button button(String label,boolean primary){Button b=new Button(this);b.setText(label);b.setTextSize(11);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextColor(white);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setPadding(dp(8),0,dp(8),0);GradientDrawable g;if(primary)g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{pink,0xFF9B6CFF});else{g=new GradientDrawable();g.setColor(0x3313192B);g.setStroke(dp(1),0x5543E8FF);}g.setCornerRadius(dp(18));b.setBackground(g);return b;}
    private TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private LinearLayout.LayoutParams margin(int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(l,t,r,b);return p;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    @Override protected void onDestroy(){super.onDestroy();if(tick!=null)handler.removeCallbacks(tick);}
}
