package com.vicountdown.studio;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;

public class DailyNotificationReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "daily_countdown";
    public static final String ACTION_DAILY = "com.vicountdown.studio.DAILY";

    @Override public void onReceive(Context context, Intent intent) {
        if (!Prefs.enabled(context)) return;
        if (System.currentTimeMillis() >= MainActivity.TARGET_MILLIS) { cancel(context); return; }
        show(context);
        NotificationScheduler.scheduleNext(context);
    }

    public static void show(Context context) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        createChannel(context);
        int days = MainActivity.daysRemaining();
        String text = days == 0 ? "É hoje. A contagem chegou ao destino." : Messages.messageForDay(days);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, CHANNEL_ID) : new Notification.Builder(context);
        b.setSmallIcon(R.drawable.ic_notification)
         .setContentTitle(days == 0 ? "VI COUNTDOWN • É HOJE" : "VI COUNTDOWN • " + days + " dias")
         .setContentText(text)
         .setStyle(new Notification.BigTextStyle().bigText(text))
         .setAutoCancel(true)
         .setCategory(Notification.CATEGORY_REMINDER);
        if (Prefs.sound(context)) b.setDefaults(Notification.DEFAULT_SOUND);
        if (Prefs.vibration(context)) b.setVibrate(new long[]{0,120,80,120});
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(60419,b.build());
    }

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"Contagem diária",NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Uma mensagem diferente por dia até a estreia.");
            nm.createNotificationChannel(ch);
        }
    }
    public static void cancel(Context context){NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);nm.cancel(60419);}
}
