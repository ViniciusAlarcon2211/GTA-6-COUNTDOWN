# VI Countdown 5.0

Projeto Android nativo em Java para o countdown fã-made de GTA VI.

## Build
- Android Gradle Plugin 8.7.3
- Gradle 8.9 (fornecido pelo GitHub Actions)
- compileSdk 35
- Sem bibliotecas externas: o app usa apenas APIs do Android para reduzir falhas de resolução/duplicidade de dependências.

## Recursos
- Interface neon animada
- Countdown em tempo real
- Mensagem diária
- Notificação diária configurável
- Som e vibração independentes
- Reagendamento após reinício do aparelho
- Central de frases
- Configurações organizadas
