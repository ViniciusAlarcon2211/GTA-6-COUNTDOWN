package com.vicecountdown.app;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends android.app.Activity {

    private static final String PREFS = "vi_countdown_prefs";
    private static final long LAUNCH = new java.util.GregorianCalendar(2026, java.util.Calendar.NOVEMBER, 19, 0, 0, 0).getTimeInMillis();
    private final Handler handler = new Handler();
    private Runnable ticker;
    private TextView days, hours, minutes, seconds, status;
    private LinearLayout content;
    private int pink = Color.rgb(255, 65, 177);
    private int purple = Color.rgb(125, 65, 255);
    private int cyan = Color.rgb(68, 221, 255);
    private int orange = Color.rgb(255, 145, 65);
    private int white = Color.WHITE;
    private int muted = Color.rgb(205, 198, 225);
    private int panel = Color.rgb(25, 15, 50);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7,5,26));
        getWindow().setNavigationBarColor(Color.rgb(7,5,26));
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 88);
        }
        showHome();
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setPadding(8, 4, 8, 4);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    private LinearLayout root() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(18, 16, 18, 18);
        r.setBackgroundResource(com.vicecountdown.app.R.drawable.bg);
        return r;
    }

    private LinearLayout scrollRoot() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout r = root();
        sv.addView(r);
        setContentView(sv);
        return r;
    }

    private GradientButton button(String label) {
        GradientButton b = new GradientButton(this);
        b.setText(label);
        b.setTextColor(white);
        b.setTextSize(14);
        b.setGravity(Gravity.CENTER);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(10, 4, 10, 4);
        return b;
    }

    private LinearLayout cardBox() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(6, 8, 6, 8);
        c.setBackgroundColor(panel);
        return c;
    }

    private void addSpace(LinearLayout r, int h) {
        Space s = new Space(this);
        r.addView(s, new LinearLayout.LayoutParams(1, h));
    }

    private void addSection(LinearLayout r, String title) {
        TextView t = text(title, 15, cyan, true);
        t.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        r.addView(t, new LinearLayout.LayoutParams(-1, 45));
    }

    private void showHome() {
        LinearLayout r = root();

        TextView top = text("VI • COUNTDOWN", 13, pink, true);
        r.addView(top, new LinearLayout.LayoutParams(-1, 34));

        TextView title = text("GRAND THEFT AUTO", 24, white, true);
        r.addView(title, new LinearLayout.LayoutParams(-1, 42));

        TextView vi = text("VI", 82, pink, true);
        vi.setShadowLayer(18, 0, 0, Color.MAGENTA);
        r.addView(vi, new LinearLayout.LayoutParams(-1, 105));

        TextView vice = text("VICE CITY", 18, cyan, true);
        r.addView(vice, new LinearLayout.LayoutParams(-1, 35));

        TextView date = text("19 • NOVEMBRO • 2026", 13, muted, true);
        r.addView(date, new LinearLayout.LayoutParams(-1, 34));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        String[] labels = {"DIAS","HORAS","MIN","SEG"};
        TextView[] values = new TextView[4];
        for (int i=0; i<4; i++) {
            LinearLayout c = cardBox();
            values[i] = text("00", 25, white, true);
            c.addView(values[i], new LinearLayout.LayoutParams(-1, 55));
            c.addView(text(labels[i], 10, pink, true), new LinearLayout.LayoutParams(-1, 28));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, 96, 1);
            cp.setMargins(3,0,3,0);
            row.addView(c, cp);
        }
        days=values[0]; hours=values[1]; minutes=values[2]; seconds=values[3];
        r.addView(row, new LinearLayout.LayoutParams(-1, 112));

        status = text("A CIDADE ESTÁ ESPERANDO…", 12, muted, true);
        r.addView(status, new LinearLayout.LayoutParams(-1, 40));

        LinearLayout quote = cardBox();
        quote.addView(text("UM NOVO CAPÍTULO COMEÇA EM", 10, muted, true));
        quote.addView(text("2026", 28, orange, true));
        quote.addView(text("O countdown continua.", 11, muted, false));
        r.addView(quote, new LinearLayout.LayoutParams(-1, 88));

        addSpace(r, 8);

        Button settings = button("⚙  CONFIGURAÇÕES");
        settings.setOnClickListener(v -> showSettings());
        r.addView(settings, new LinearLayout.LayoutParams(-1, 55));

        Button messages = button("💬  MENSAGENS DO COUNTDOWN");
        messages.setOnClickListener(v -> showMessages());
        r.addView(messages, new LinearLayout.LayoutParams(-1, 55));

        Button about = button("ⓘ  SOBRE O APP");
        about.setOnClickListener(v -> showAbout());
        r.addView(about, new LinearLayout.LayoutParams(-1, 55));

        setContentView(r);
        startTicker();
    }

    private void startTicker() {
        if (ticker != null) handler.removeCallbacks(ticker);
        ticker = new Runnable() {
            @Override public void run() {
                updateCountdown();
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(ticker);
    }

    private void updateCountdown() {
        long diff = LAUNCH - System.currentTimeMillis();
        if (diff <= 0) {
            days.setText("00"); hours.setText("00"); minutes.setText("00"); seconds.setText("00");
            status.setText("🚨 É HOJE. O COUNTDOWN TERMINOU.");
            return;
        }
        long total = diff / 1000;
        long d = total / 86400;
        total %= 86400;
        long h = total / 3600;
        total %= 3600;
        long m = total / 60;
        long s = total % 60;
        days.setText(String.valueOf(d));
        hours.setText(String.format(Locale.US, "%02d", h));
        minutes.setText(String.format(Locale.US, "%02d", m));
        seconds.setText(String.format(Locale.US, "%02d", s));

        if (d <= 1) status.setText("🔥 FALTA MUITO POUCO.");
        else if (d <= 7) status.setText("🚨 ÚLTIMA SEMANA.");
        else if (d <= 30) status.setText("🌴 VICE CITY ESTÁ CADA VEZ MAIS PERTO.");
        else status.setText("A CIDADE ESTÁ ESPERANDO…");
    }

    private void showSettings() {
        LinearLayout r = scrollRoot();
        r.addView(text("CONFIGURAÇÕES", 28, white, true), new LinearLayout.LayoutParams(-1, 60));
        r.addView(text("PERSONALIZE O SEU COUNTDOWN", 12, pink, true), new LinearLayout.LayoutParams(-1, 36));

        addSection(r, "🔔 NOTIFICAÇÕES");

        Switch daily = new Switch(this);
        daily.setText("Notificação diária");
        daily.setTextColor(white);
        daily.setTextSize(16);
        daily.setChecked(prefs().getBoolean("daily", true));
        r.addView(daily, new LinearLayout.LayoutParams(-1, 55));

        TextView time = text(getTimeLabel(), 16, white, true);
        r.addView(time, new LinearLayout.LayoutParams(-1, 45));

        Button choose = button("🕘  Escolher horário");
        choose.setOnClickListener(v -> chooseTime(time));
        r.addView(choose, new LinearLayout.LayoutParams(-1, 55));

        Button test = button("🔔  Enviar notificação de teste");
        test.setOnClickListener(v -> sendTestNotification());
        r.addView(test, new LinearLayout.LayoutParams(-1, 55));

        addSection(r, "🎯 MARCOS");

        String[] marks = {"100 dias","50 dias","30 dias","10 dias","7 dias","3 dias","1 dia","Lançamento"};
        for (String mark : marks) {
            CheckBox cb = new CheckBox(this);
            cb.setText(mark);
            cb.setTextColor(muted);
            cb.setTextSize(15);
            cb.setChecked(prefs().getBoolean("mark_"+mark, false));
            cb.setOnCheckedChangeListener((buttonView, checked) ->
                    prefs().edit().putBoolean("mark_"+mark, checked).apply());
            r.addView(cb, new LinearLayout.LayoutParams(-1, 43));
        }

        addSection(r, "🎨 APARÊNCIA");

        TextView info = text("Tema: Neon Vice City\nInterface escura com rosa, roxo, azul e laranja.", 13, muted, false);
        info.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        r.addView(info, new LinearLayout.LayoutParams(-1, 65));

        Button save = button("💾  SALVAR E ATIVAR");
        save.setOnClickListener(v -> {
            prefs().edit().putBoolean("daily", daily.isChecked()).apply();
            scheduleDaily();
            Toast.makeText(this, "Configurações salvas.", Toast.LENGTH_SHORT).show();
        });
        r.addView(save, new LinearLayout.LayoutParams(-1, 58));

        Button back = button("←  VOLTAR");
        back.setOnClickListener(v -> showHome());
        r.addView(back, new LinearLayout.LayoutParams(-1, 58));
    }

    private String getTimeLabel() {
        int h = prefs().getInt("hour", 9);
        int m = prefs().getInt("minute", 0);
        return String.format(Locale.US, "Horário diário: %02d:%02d", h, m);
    }

    private void chooseTime(TextView label) {
        int h = prefs().getInt("hour", 9);
        int m = prefs().getInt("minute", 0);
        new TimePickerDialog(this, (view, hour, minute) -> {
            prefs().edit().putInt("hour",hour).putInt("minute",minute).apply();
            label.setText(String.format(Locale.US, "Horário diário: %02d:%02d", hour, minute));
        }, h, m, true).show();
    }

    private void scheduleDaily() {
        if (!prefs().getBoolean("daily", true)) {
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            Intent intent = new Intent(this, DailyNotificationReceiver.class);
            android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(
                    this, 707, intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
            return;
        }

        Intent intent = new Intent(this, DailyNotificationReceiver.class);
        android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(
                this, 707, intent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);

        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, prefs().getInt("hour",9));
        c.set(Calendar.MINUTE, prefs().getInt("minute",0));
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);

        AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY, pi);
    }

    private void sendTestNotification() {
        Intent intent = new Intent(this, DailyNotificationReceiver.class);
        sendBroadcast(intent);
        Toast.makeText(this, "Notificação enviada.", Toast.LENGTH_SHORT).show();
    }

    private void showMessages() {
        LinearLayout r = scrollRoot();
        r.addView(text("MENSAGENS", 28, white, true), new LinearLayout.LayoutParams(-1, 60));
        r.addView(text("Frases originais para as notificações diárias", 12, pink, true),
                new LinearLayout.LayoutParams(-1, 40));

        String[] messages = {
            "Bom dia, seu merdinha. O GTA VI ainda está chegando.",
            "Bom dia! Vice City está cada vez mais perto.",
            "Mais um dia sobrevivido. Mais um dia a menos no countdown.",
            "A cidade está esperando. Confira quantos dias faltam.",
            "Seu lembrete diário: GTA VI não vai se lançar sozinho.",
            "☀️ Bom dia. O sol nasceu e o countdown continua.",
            "🚗 Mais um dia rumo a Vice City.",
            "🌴 Vice City te espera. Aguenta mais um pouco.",
            "🎮 Hora de lembrar: o grande dia está chegando.",
            "🔥 O contador não para. Você está de olho?",
            "De GTA V para GTA VI: a próxima parada está chegando.",
            "Los Santos fica para trás. O countdown segue para Vice City.",
            "Mais perto do que ontem. Menos perto do que amanhã.",
            "Hoje não é o lançamento. Mas está mais perto.",
            "🚨 Alerta da cidade: o countdown continua.",
            "VI Countdown: porque olhar o contador todo dia é importante.",
            "Bom dia, criminoso digital. Hora de conferir o contador.",
            "O mapa ainda não abriu, mas a contagem já começou.",
            "Aquele lembrete que ninguém pediu, mas todo fã queria.",
            "Mais 24 horas passaram. Confira a contagem."
        };
        for (String msg : messages) {
            LinearLayout c = cardBox();
            TextView t = text("“" + msg + "”", 14, muted, false);
            t.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
            c.addView(t, new LinearLayout.LayoutParams(-1, 70));
            r.addView(c, new LinearLayout.LayoutParams(-1, 78));
        }

        Button back = button("←  VOLTAR");
        back.setOnClickListener(v -> showHome());
        r.addView(back, new LinearLayout.LayoutParams(-1, 58));
    }

    private void showAbout() {
        LinearLayout r = scrollRoot();
        r.addView(text("SOBRE", 28, white, true), new LinearLayout.LayoutParams(-1, 65));
        r.addView(text("VI COUNTDOWN", 24, pink, true), new LinearLayout.LayoutParams(-1, 55));
        TextView body = text(
            "Um countdown independente criado para acompanhar a chegada de GTA VI.\n\n" +
            "• Contagem em tempo real\n" +
            "• Notificações diárias\n" +
            "• Marcos de lançamento\n" +
            "• Mensagens originais\n" +
            "• Interface neon inspirada na estética de Vice City\n\n" +
            "Este aplicativo não é oficial nem afiliado à Rockstar Games.",
            15, muted, false);
        body.setGravity(Gravity.LEFT | Gravity.TOP);
        r.addView(body, new LinearLayout.LayoutParams(-1, 260));
        Button back = button("←  VOLTAR");
        back.setOnClickListener(v -> showHome());
        r.addView(back, new LinearLayout.LayoutParams(-1, 58));
    }

    @Override protected void onResume() {
        super.onResume();
        if (prefs().getBoolean("daily", true)) scheduleDaily();
    }

    @Override protected void onDestroy() {
        if (ticker != null) handler.removeCallbacks(ticker);
        super.onDestroy();
    }

    public static class GradientButton extends Button {
        public GradientButton(Context c) {
            super(c);
            android.graphics.drawable.GradientDrawable gd =
                new android.graphics.drawable.GradientDrawable();
            gd.setColor(Color.rgb(35,20,72));
            gd.setCornerRadius(22);
            gd.setStroke(1, Color.rgb(115,70,180));
            setBackground(gd);
        }
    }
}
