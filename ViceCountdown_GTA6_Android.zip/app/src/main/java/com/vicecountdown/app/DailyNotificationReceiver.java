package com.vicecountdown.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;
import java.util.Random;

public class DailyNotificationReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "daily_countdown";
    private static final long LAUNCH = new java.util.GregorianCalendar(2026, Calendar.NOVEMBER, 19, 0, 0, 0).getTimeInMillis();

    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            schedule(context);
            return;
        }

        android.content.SharedPreferences p =
            context.getSharedPreferences("vi_countdown_prefs", Context.MODE_PRIVATE);
        if (!p.getBoolean("daily", true)) return;

        long diff = LAUNCH - System.currentTimeMillis();
        long days = diff > 0 ? diff / 86400000L : 0;

        String message = milestoneMessage(p, days);
        if (message == null) {
            String[] messages = {
                "Bom dia, seu merdinha. O GTA VI ainda está chegando.",
                "Bom dia! Vice City está cada vez mais perto.",
                "Mais um dia sobrevivido. Mais um dia a menos no countdown.",
                "A cidade está esperando. Confira quantos dias faltam.",
                "Seu lembrete diário: GTA VI não vai se lançar sozinho.",
                "☀️ Bom dia. O sol nasceu e o countdown continua.",
                "🚗 Mais um dia rumo a Vice City.",
                "🌴 Vice City te espera. Aguenta mais um pouco.",
                "🎮 Hora de lembrar: o grande dia está chegando.",
                "🔥 O contador não para. Você está de olho?",
                "De GTA V para GTA VI: a próxima parada está chegando.",
                "Los Santos fica para trás. O countdown segue para Vice City.",
                "Mais perto do que ontem. Menos perto do que amanhã.",
                "Hoje não é o lançamento. Mas está mais perto.",
                "🚨 Alerta da cidade: o countdown continua.",
                "VI Countdown: porque olhar o contador todo dia é importante.",
                "Bom dia, criminoso digital. Hora de conferir o contador.",
                "O mapa ainda não abriu, mas a contagem já começou.",
                "Aquele lembrete que ninguém pediu, mas todo fã queria.",
                "Mais 24 horas passaram. Confira a contagem."
            };
            message = messages[new Random().nextInt(messages.length)];
        }

        showNotification(context, message);
    }

    private String milestoneMessage(android.content.SharedPreferences p, long days) {
        long[] marks = {100,50,30,10,7,3,1,0};
        String[] names = {"100 dias","50 dias","30 dias","10 dias","7 dias","3 dias","1 dia","Lançamento"};
        for (int i=0; i<marks.length; i++) {
            if (days == marks[i] && p.getBoolean("mark_"+names[i], false)) {
                return "🚨 MARCO DO COUNTDOWN: " + names[i] + "!";
            }
        }
        return null;
    }

    private void showNotification(Context context, String message) {
        NotificationManager manager =
            (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "VI Countdown", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Mensagens diárias do countdown");
            manager.createNotificationChannel(channel);
        }

        Intent open = new Intent(context, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(
            context, 100, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        android.app.Notification.Builder builder =
            Build.VERSION.SDK_INT >= 26
            ? new android.app.Notification.Builder(context, CHANNEL_ID)
            : new android.app.Notification.Builder(context);

        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("VI COUNTDOWN")
            .setContentText(message)
            .setStyle(new android.app.Notification.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setContentIntent(pending);

        manager.notify(700, builder.build());
    }

    private static void schedule(Context context) {
        android.content.SharedPreferences p =
            context.getSharedPreferences("vi_countdown_prefs", Context.MODE_PRIVATE);
        if (!p.getBoolean("daily", true)) return;

        Intent intent = new Intent(context, DailyNotificationReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
            context, 707, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, p.getInt("hour", 9));
        c.set(Calendar.MINUTE, p.getInt("minute", 0));
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis())
            c.add(Calendar.DAY_OF_YEAR, 1);

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        am.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            c.getTimeInMillis(),
            AlarmManager.INTERVAL_DAY,
            pi);
    }
}
