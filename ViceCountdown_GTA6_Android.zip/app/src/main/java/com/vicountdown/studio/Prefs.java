package com.vicountdown.studio;

import android.content.*;

public final class Prefs {
    private static final String P = "vi_settings";
    private static SharedPreferences p(Context c) { return c.getSharedPreferences(P, Context.MODE_PRIVATE); }

    public static boolean enabled(Context c) { return p(c).getBoolean("enabled", true); }
    public static void enabled(Context c, boolean v) { p(c).edit().putBoolean("enabled", v).apply(); }

    public static int hour(Context c) { return p(c).getInt("hour", 9); }
    public static int minute(Context c) { return p(c).getInt("minute", 0); }
    public static void time(Context c, int h, int m) { p(c).edit().putInt("hour", h).putInt("minute", m).apply(); }

    public static boolean sound(Context c) { return p(c).getBoolean("sound", true); }
    public static void sound(Context c, boolean v) { p(c).edit().putBoolean("sound", v).apply(); }

    public static boolean vibration(Context c) { return p(c).getBoolean("vibration", true); }
    public static void vibration(Context c, boolean v) { p(c).edit().putBoolean("vibration", v).apply(); }

    public static boolean milestones(Context c) { return p(c).getBoolean("milestones", true); }
    public static void milestones(Context c, boolean v) { p(c).edit().putBoolean("milestones", v).apply(); }

    public static String style(Context c) { return p(c).getString("style", "mix"); }
    public static void style(Context c, String v) { p(c).edit().putString("style", v).apply(); }

    private Prefs() {}
}