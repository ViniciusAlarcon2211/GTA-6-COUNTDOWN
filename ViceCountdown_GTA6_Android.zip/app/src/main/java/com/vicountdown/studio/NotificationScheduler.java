package com.vicountdown.studio;

import android.app.*;
import android.content.*;
import java.util.*;

public final class NotificationScheduler {
    public static void schedule(Context context) {
        if (!Prefs.enabled(context)) { cancel(context); return; }
        scheduleNext(context);
    }

    public static void scheduleNext(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(context);
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, Prefs.hour(context));
        c.set(Calendar.MINUTE, Prefs.minute(context));
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);

        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
    }

    public static void cancel(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pending(context));
    }

    private static PendingIntent pending(Context context) {
        Intent i = new Intent(context, DailyNotificationReceiver.class);
        i.setAction(DailyNotificationReceiver.ACTION_DAILY);
        return PendingIntent.getBroadcast(
            context, 9901, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private NotificationScheduler() {}
}