package com.vicountdown.studio;

import android.content.*;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Prefs.enabled(context)) NotificationScheduler.schedule(context);
    }
}