package com.vicountdown.studio;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import java.text.SimpleDateFormat;
import java.util.*;

public class DailyNotificationReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "daily_countdown";
    public static final String ACTION_DAILY = "com.vicountdown.studio.DAILY";

    @Override public void onReceive(Context context, Intent intent) {
        if (!Prefs.enabled(context)) return;
        long target = MainActivity.TARGET_MILLIS;
        long now = System.currentTimeMillis();
        if (now >= target) {
            cancel(context);
            return;
        }
        show(context);
        NotificationScheduler.scheduleNext(context);
    }

    public static void show(Context context) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel(context);

        int days = MainActivity.daysRemaining();
        int dayIndex = (int)Math.max(0, days);
        String text = days == 0 ? "É hoje. A contagem chegou ao destino." : Messages.messageForDay(dayIndex);

        NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.vicountdown.studio.R.drawable.ic_notification)
            .setContentTitle(days == 0 ? "VI COUNTDOWN • É HOJE" : "VI COUNTDOWN • " + days + " dias")
            .setContentText(text)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        if (Prefs.sound(context)) b.setDefaults(NotificationCompat.DEFAULT_SOUND);
        if (Prefs.vibration(context)) b.setVibrate(new long[]{0, 120, 80, 120});

        nm.notify(60419, b.build());
    }

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Contagem diária", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Uma mensagem diferente por dia até a estreia.");
            nm.createNotificationChannel(ch);
        }
    }

    public static void cancel(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(60419);
    }
}