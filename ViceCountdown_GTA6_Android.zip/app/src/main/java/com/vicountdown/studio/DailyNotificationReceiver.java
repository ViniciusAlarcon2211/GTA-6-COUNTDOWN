package com.vicountdown.studio;

import android.app.*;
import android.content.*;
import android.os.Build;
import java.util.*;

public class DailyNotificationReceiver extends BroadcastReceiver {
    static final String CHANNEL="daily";
    static final long LAUNCH=new GregorianCalendar(2026,Calendar.NOVEMBER,19,0,0,0).getTimeInMillis();
    @Override public void onReceive(Context c, Intent i){
        if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())){schedule(c);return;}
        android.content.SharedPreferences p=c.getSharedPreferences("vi_prefs",Context.MODE_PRIVATE);
        if(!p.getBoolean("daily",true)) return;
        long diff=LAUNCH-System.currentTimeMillis(); long days=diff>0?diff/86400000L:0;
        String msg=milestone(p,days);
        if(msg==null) msg=choose(p.getString("mode","Aleatórias — recomendado"));
        show(c,msg);
    }
    static String milestone(android.content.SharedPreferences p,long d){
        long[] n={100,50,30,10,7,3,1,0};String[] k={"100 dias","50 dias","30 dias","10 dias","7 dias","3 dias","1 dia","Lançamento"};
        for(int i=0;i<n.length;i++) if(d==n[i]&&p.getBoolean("mark_"+k[i],false)) return "🚨 MARCO DO COUNTDOWN: "+k[i]+"!";
        return null;
    }
    static String choose(String mode){
        String[] a=Messages.ALL;
        if("GTA / Vice City".equals(mode)){
            String[] q={"🌴 Vice City está no horizonte.","🚗 Mais um dia rumo à cidade.","🌆 Neon aceso. Countdown ativo.","🗺️ Próxima parada: Vice City.","🎮 A próxima aventura está chegando.","De GTA V para GTA VI: seguimos na estrada.","🚦 Sinal verde para continuar esperando.","📍 Destino marcado: 19/11/2026."};
            return q[new Random().nextInt(q.length)];
        }
        if("Motivação / countdown".equals(mode)){
            String[] q={"Mais perto do que ontem.","Um dia de cada vez.","Cada segundo conta.","A espera está diminuindo.","Você está avançando sem sair do lugar.","Mais um dia completado com sucesso.","O próximo marco está chegando.","Calma. O tempo está fazendo o trabalho dele."};
            return q[new Random().nextInt(q.length)];
        }
        if("Humor / provocação".equals(mode)){
            String[] q={"Bom dia, seu merdinha. O countdown continua.","Você abriu o app de novo. Respeito.","Hoje não é o lançamento. Ainda.","Seu alarme emocional diário chegou.","Não precisa perguntar. O contador sabe.","Bom dia, seu apressado. Ainda falta.","Uma notificação inútil e divertida acabou de chegar.","Sim, o número mudou. Pode olhar."};
            return q[new Random().nextInt(q.length)];
        }
        return a[new Random().nextInt(a.length)];
    }
    static void show(Context c,String msg){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"VI Countdown",NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Mensagens diárias e marcos do countdown");nm.createNotificationChannel(ch);
        }
        Intent open=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,70,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(c,CHANNEL):new android.app.Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("VI COUNTDOWN").setContentText(msg)
         .setStyle(new android.app.Notification.BigTextStyle().bigText(msg)).setAutoCancel(true).setContentIntent(pi);
        nm.notify(700,b.build());
    }
    static void schedule(Context c){
        android.content.SharedPreferences p=c.getSharedPreferences("vi_prefs",Context.MODE_PRIVATE);
        if(!p.getBoolean("daily",true))return;
        Intent i=new Intent(c,DailyNotificationReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(c,700,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Calendar x=Calendar.getInstance();x.set(Calendar.HOUR_OF_DAY,p.getInt("hour",9));x.set(Calendar.MINUTE,p.getInt("minute",0));x.set(Calendar.SECOND,0);x.set(Calendar.MILLISECOND,0);
        if(x.getTimeInMillis()<=System.currentTimeMillis())x.add(Calendar.DAY_OF_YEAR,1);
        ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).setInexactRepeating(AlarmManager.RTC_WAKEUP,x.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
    }
}
