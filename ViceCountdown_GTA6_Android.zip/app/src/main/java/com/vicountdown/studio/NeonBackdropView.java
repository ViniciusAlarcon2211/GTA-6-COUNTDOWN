package com.vicountdown.studio;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.view.View;
import android.view.animation.LinearInterpolator;

public class NeonBackdropView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float pulse = 0f;

    public NeonBackdropView(Context c) {
        super(c);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(5200);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setInterpolator(new LinearInterpolator());
        a.addUpdateListener(v -> { pulse = (float)v.getAnimatedValue(); invalidate(); });
        a.start();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w = getWidth(), h = getHeight();
        p.setShader(new LinearGradient(0,0,w,h, new int[]{Color.rgb(5,6,12),Color.rgb(15,13,35),Color.rgb(35,10,38)}, null, Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p);

        // atmospheric glow
        float glowX = w * (0.25f + pulse * 0.55f);
        p.setShader(new RadialGradient(glowX, h*0.18f, w*0.75f,
                new int[]{0x5543E8FF,0x1A9B6CFF,0x00FF4FB3}, null, Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p);

        // sun
        p.setShader(new RadialGradient(w*0.76f, h*0.20f, Math.min(w,h)*0.17f,
                new int[]{0x99FFB56B,0x22FF4FB3,0x00111122}, null, Shader.TileMode.CLAMP));
        c.drawCircle(w*0.76f,h*0.20f,Math.min(w,h)*0.18f,p);

        // skyline
        p.setShader(null);
        p.setColor(0xCC070A14);
        float base = h*0.73f;
        float[] xs = {0.00f,0.10f,0.18f,0.28f,0.39f,0.50f,0.61f,0.72f,0.84f,0.94f};
        float[] hs = {0.18f,0.31f,0.22f,0.38f,0.26f,0.44f,0.23f,0.34f,0.25f,0.41f};
        for(int i=0;i<xs.length;i++){
            float x=xs[i]*w, bw=w*0.12f, bh=hs[i]*h;
            c.drawRect(x,base-bh,x+bw,base,p);
            line.setColor(i%2==0 ? 0xAAFF4FB3 : 0xAA43E8FF);
            line.setStrokeWidth(2);
            for(float yy=base-bh+16; yy<base-8; yy+=18){
                c.drawLine(x+10,yy,x+bw-10,yy,line);
            }
        }

        // palm silhouettes
        p.setColor(0xEE05060B);
        for(int k=0;k<3;k++){
            float x=w*(0.08f+k*0.42f), y=base+8;
            c.drawRect(x-3,y-90,x+3,y,p);
            Path palm=new Path();
            palm.moveTo(x,y-88); palm.cubicTo(x-25,y-102,x-34,y-94,x-40,y-86);
            palm.moveTo(x,y-88); palm.cubicTo(x+20,y-105,x+31,y-96,x+39,y-84);
            palm.moveTo(x,y-88); palm.cubicTo(x-4,y-116,x+2,y-124,x+9,y-130);
            c.drawPath(palm,p);
        }

        // road perspective
        line.setColor(0x5533DDF5);
        line.setStrokeWidth(2);
        float roadTop=base+2, roadBottom=h;
        c.drawLine(w*0.48f,roadTop,w*0.12f,roadBottom,line);
        c.drawLine(w*0.52f,roadTop,w*0.88f,roadBottom,line);
        line.setColor(0x44FF4FB3);
        c.drawLine(w*0.50f,roadTop,w*0.50f,roadBottom,line);

        // scanlines
        line.setColor(0x12000000);
        line.setStrokeWidth(1);
        for(int y=0;y<h;y+=7) c.drawLine(0,y,w,y,line);
    }
}