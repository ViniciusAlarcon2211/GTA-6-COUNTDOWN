package com.vicountdown.studio;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.view.View;
import android.view.animation.LinearInterpolator;

public class NeonBackdropView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float pulse;
    public NeonBackdropView(Context c) {
        super(c);
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(9000); a.setRepeatCount(ValueAnimator.INFINITE); a.setInterpolator(new LinearInterpolator());
        a.addUpdateListener(v -> { pulse = (float)v.getAnimatedValue(); invalidate(); });
        a.start();
    }
    @Override protected void onDraw(Canvas c) {
        int w=getWidth(), h=getHeight();
        p.setShader(new LinearGradient(0,0,w,h,new int[]{Color.rgb(7,9,18),Color.rgb(11,13,27),Color.rgb(19,10,27)},null,Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p);
        float x=w*(0.18f+0.64f*pulse);
        p.setShader(new RadialGradient(x,h*.10f,w*.58f,new int[]{0x243FD9E8,0x0C8D5BC5,0x00000000},null,Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p);
        p.setShader(new RadialGradient(w*.78f,h*.17f,Math.min(w,h)*.14f,new int[]{0x35FF86B9,0x0CFF4FB3,0x00000000},null,Shader.TileMode.CLAMP));
        c.drawCircle(w*.78f,h*.17f,Math.min(w,h)*.14f,p);
        p.setShader(null);
        p.setColor(0x14000000);
        c.drawRect(0,h*.72f,w,h,p);
        p.setColor(0x1838D5E7);
        p.setStrokeWidth(1);
        for(int i=0;i<5;i++) c.drawLine(w*.10f+i*w*.20f,h*.72f,w*.50f+i*w*.01f,h,p);
    }
}
