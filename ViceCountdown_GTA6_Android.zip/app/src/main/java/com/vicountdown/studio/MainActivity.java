package com.vicountdown.studio;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.materialswitch.MaterialSwitch;
import java.text.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    // Officially announced by Rockstar Games.
    public static final long TARGET_MILLIS = new GregorianCalendar(2026, Calendar.NOVEMBER, 19, 0, 0, 0).getTimeInMillis();
    private static final int NOTIF_REQ = 701;
    private LinearLayout content;
    private TextView countdown;
    private TextView subCountdown;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable tick;
    private int currentTab = 0;

    private int pink = Color.rgb(255,79,179);
    private int cyan = Color.rgb(67,232,255);
    private int white = Color.rgb(255,249,255);
    private int muted = Color.rgb(169,172,193);

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,6,12));
        getWindow().setNavigationBarColor(Color.rgb(5,6,12));
        DailyNotificationReceiver.createChannel(this);
        buildShell();
        requestNotificationsIfNeeded();
        NotificationScheduler.schedule(this);
    }

    private void buildShell() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5,6,12));

        NeonBackdropView bg = new NeonBackdropView(this);
        root.addView(bg, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(8), dp(18), dp(10));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);

        shell.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        shell.addView(navBar(), new LinearLayout.LayoutParams(-1,dp(74)));

        root.addView(shell, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        showHome();
    }

    private View navBar() {
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(10),dp(7),dp(10),dp(9));
        nav.setBackgroundColor(0xEE080A13);

        String[] labels = {"⌂\nINÍCIO","✦\nFRASES","⚙\nAJUSTES"};
        for (int i=0;i<3;i++) {
            final int tab=i;
            TextView t = new TextView(this);
            t.setText(labels[i]);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(11);
            t.setTypeface(null, android.graphics.Typeface.BOLD);
            t.setTextColor(i==0 ? white : muted);
            t.setPadding(4,4,4,4);
            t.setOnClickListener(v -> {
                currentTab=tab;
                if(tab==0) showHome(); else if(tab==1) showMessages(); else showSettings();
            });
            nav.addView(t, new LinearLayout.LayoutParams(0,-1,1));
        }
        return nav;
    }

    private void showHome() {
        content.removeAllViews();
        TextView eyebrow = text("VI COUNTDOWN", 12, cyan);
        eyebrow.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(eyebrow, margin(0,dp(10),0,dp(3)));

        TextView title = text("LEONIDA\nIS LOADING", 30, white);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(title, margin(0,0,0,dp(5)));

        TextView official = text("19 NOV 2026  •  lançamento oficial anunciado pela Rockstar Games", 11, muted);
        content.addView(official, margin(0,0,0,dp(16)));

        MaterialCardView hero = card(true);
        LinearLayout h = new LinearLayout(this); h.setOrientation(LinearLayout.VERTICAL); h.setPadding(dp(20),dp(18),dp(20),dp(18));
        TextView tag=text("CONTAGEM PRINCIPAL",11,cyan); tag.setTypeface(null,1); h.addView(tag);
        countdown=text("—",48,white); countdown.setTypeface(null,1); countdown.setGravity(Gravity.CENTER_HORIZONTAL); h.addView(countdown, margin(0,dp(5),0,0));
        subCountdown=text("até o próximo grande capítulo",13,muted); subCountdown.setGravity(Gravity.CENTER_HORIZONTAL); h.addView(subCountdown);
        h.addView(progressBar(), margin(0,dp(18),0,dp(2)));
        TextView date=text("19 de novembro de 2026",12,white); date.setGravity(Gravity.CENTER_HORIZONTAL); h.addView(date);
        hero.addView(h);
        content.addView(hero, margin(0,0,0,dp(14)));

        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statCard("DIAS","dias restantes"), new LinearLayout.LayoutParams(0,dp(92),1));
        stats.addView(space(10), new LinearLayout.LayoutParams(dp(10),1));
        stats.addView(statCard("ATUALIZA","ao abrir"), new LinearLayout.LayoutParams(0,dp(92),1));
        content.addView(stats, margin(0,0,0,dp(14)));

        MaterialCardView message=card(false);
        LinearLayout mh=new LinearLayout(this); mh.setOrientation(LinearLayout.VERTICAL); mh.setPadding(dp(17),dp(16),dp(17),dp(16));
        TextView mtag=text("📡 MENSAGEM DO DIA",11,pink); mtag.setTypeface(null,1); mh.addView(mtag);
        int d=daysRemaining();
        TextView msg=text(Messages.messageForDay(Math.max(0,d)),16,white); msg.setTypeface(null,1); mh.addView(msg, margin(0,dp(8),0,dp(5)));
        TextView hint=text("Uma mensagem diferente por dia, sem depender de frases copiadas do jogo.",11,muted); mh.addView(hint);
        message.addView(mh);
        content.addView(message, margin(0,0,0,dp(14)));

        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        MaterialButton notif=button("NOTIFICAÇÕES", true); notif.setOnClickListener(v -> showSettings());
        MaterialButton phrases=button("CENTRAL DE FRASES", false); phrases.setOnClickListener(v -> showMessages());
        row.addView(notif,new LinearLayout.LayoutParams(0,dp(52),1));
        row.addView(space(9),new LinearLayout.LayoutParams(dp(9),1));
        row.addView(phrases,new LinearLayout.LayoutParams(0,dp(52),1));
        content.addView(row, margin(0,0,0,dp(14)));

        TextView footer=text("VI COUNTDOWN 4.0  •  fã-made  •  não afiliado à Rockstar Games",10,muted);
        footer.setGravity(Gravity.CENTER); content.addView(footer, margin(0,dp(8),0,dp(20)));

        startTicker();
    }

    private View progressBar() {
        LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL);
        ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        p.setMax(100); p.setProgress(progressPercent());
        p.setProgressTintList(android.content.res.ColorStateList.valueOf(pink));
        wrap.addView(p,new LinearLayout.LayoutParams(-1,dp(7)));
        return wrap;
    }

    private int progressPercent() {
        long now=System.currentTimeMillis();
        long start=new GregorianCalendar(2025,Calendar.MAY,26).getTimeInMillis();
        if(now<=start)return 0;
        if(now>=TARGET_MILLIS)return 100;
        return (int)Math.max(0,Math.min(100,((now-start)*100.0)/(TARGET_MILLIS-start)));
    }

    private MaterialCardView statCard(String big,String small) {
        MaterialCardView c=card(false);
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setGravity(Gravity.CENTER); l.setPadding(8,8,8,8);
        TextView a=text(big,18,white); a.setTypeface(null,1); a.setGravity(Gravity.CENTER); l.addView(a);
        TextView b=text(small,10,muted); b.setGravity(Gravity.CENTER); l.addView(b);
        c.addView(l); return c;
    }

    private void showMessages() {
        content.removeAllViews();
        content.addView(text("CENTRAL DE FRASES",26,white), margin(0,dp(10),0,dp(3)));
        content.addView(text("Mensagens originais em clima de GTA, com foco em GTA VI, Vice City, Leonida e referências gerais aos jogos.",12,muted), margin(0,0,0,dp(16)));

        String[] sections={"GTA VI / LEONIDA","VICE CITY / NEON","LEGADO GTA"};
        int[] starts={0,60,120};
        int[] ends={60,120,Messages.ALL.length};
        for(int s=0;s<sections.length;s++){
            TextView head=text(sections[s],11,s==0?cyan:(s==1?pink:0xFFFFA45B)); head.setTypeface(null,1);
            content.addView(head, margin(0,dp(7),0,dp(8)));
            int count=0;
            for(int i=starts[s];i<ends[s] && count<18;i++,count++){
                MaterialCardView c=card(false);
                TextView t=text("“"+Messages.ALL[i]+"”",14,white);
                t.setPadding(dp(15),dp(14),dp(15),dp(14));
                c.addView(t);
                content.addView(c, margin(0,0,0,dp(8)));
            }
        }
    }

    private void showSettings() {
        content.removeAllViews();
        content.addView(text("AJUSTES",26,white), margin(0,dp(10),0,dp(3)));
        content.addView(text("Tudo importante em um só lugar. Você escolhe o ritmo; o app cuida da contagem.",12,muted), margin(0,0,0,dp(15)));

        section("NOTIFICAÇÕES");
        MaterialSwitch sw=switcher("Mensagem diária", "Receba uma mensagem diferente todos os dias.");
        sw.setChecked(Prefs.enabled(this));
        sw.setOnCheckedChangeListener((b,v)->{Prefs.enabled(this,v);NotificationScheduler.schedule(this);});
        content.addView(settingRow(sw),margin(0,0,0,dp(8)));

        TextView time=text("Horário das mensagens",13,white); content.addView(time,margin(0,dp(7),0,dp(5)));
        MaterialButton timeBtn=button(String.format(Locale.getDefault(),"TODOS OS DIAS • %02d:%02d",Prefs.hour(this),Prefs.minute(this)),false);
        timeBtn.setOnClickListener(v->pickTime(timeBtn));
        content.addView(timeBtn,margin(0,0,0,dp(8)));

        MaterialButton test=button("ENVIAR NOTIFICAÇÃO DE TESTE",true);
        test.setOnClickListener(v->{
            DailyNotificationReceiver.createChannel(this);
            if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
                requestNotificationsIfNeeded();
                return;
            }
            DailyNotificationReceiver.show(this);
            Toast.makeText(this,"Notificação enviada.",Toast.LENGTH_SHORT).show();
        });
        content.addView(test,margin(0,0,0,dp(10)));

        MaterialSwitch sound=switcher("Som", "Usar o som padrão da notificação.");
        sound.setChecked(Prefs.sound(this)); sound.setOnCheckedChangeListener((b,v)->Prefs.sound(this,v));
        content.addView(settingRow(sound),margin(0,0,0,dp(8)));

        MaterialSwitch vib=switcher("Vibração", "Usar vibração curta ao notificar.");
        vib.setChecked(Prefs.vibration(this)); vib.setOnCheckedChangeListener((b,v)->Prefs.vibration(this,v));
        content.addView(settingRow(vib),margin(0,0,0,dp(8)));

        section("MARCOS");
        MaterialSwitch milestones=switcher("Mensagens especiais", "Destacar marcos como 30, 7, 1 dia e o dia do lançamento.");
        milestones.setChecked(Prefs.milestones(this)); milestones.setOnCheckedChangeListener((b,v)->Prefs.milestones(this,v));
        content.addView(settingRow(milestones),margin(0,0,0,dp(8)));

        TextView list=text("Marcos ativos: 180 • 100 • 60 • 30 • 14 • 7 • 3 • 1 • HOJE",11,muted);
        content.addView(list,margin(dp(14),0,0,dp(12)));

        section("ESTILO DAS MENSAGENS");
        RadioGroup rg=new RadioGroup(this); rg.setOrientation(RadioGroup.VERTICAL);
        String[] labels={"MIX VICE CITY • LEONIDA","GTA VI / CIDADE / MAPA","LEGADO GTA • CLIMA CLÁSSICO","MOTIVAÇÃO / COUNTDOWN"};
        String[] vals={"mix","vi","legacy","motivation"};
        String saved=Prefs.style(this);
        for(int i=0;i<labels.length;i++){
            RadioButton rb=new RadioButton(this); rb.setText(labels[i]); rb.setTextColor(white); rb.setTextSize(13); rb.setButtonTintList(android.content.res.ColorStateList.valueOf(pink));
            rb.setTag(vals[i]); rb.setPadding(0,dp(5),0,dp(5)); if(saved.equals(vals[i]))rb.setChecked(true);
            rg.addView(rb);
        }
        rg.setOnCheckedChangeListener((g,id)->{RadioButton rb=g.findViewById(id); if(rb!=null)Prefs.style(this,String.valueOf(rb.getTag()));});
        content.addView(rg,margin(0,0,0,dp(12)));

        section("APARÊNCIA");
        TextView appInfo=text("Tema neon noturno • fundo animado • cards translúcidos • tipografia grande • contraste alto",12,muted);
        content.addView(appInfo,margin(0,0,0,dp(12)));

        MaterialButton about=button("SOBRE O APP",false); about.setOnClickListener(v->showAbout());
        content.addView(about,margin(0,0,0,dp(20)));
    }

    private void showAbout() {
        content.removeAllViews();
        content.addView(text("SOBRE",26,white),margin(0,dp(10),0,dp(12)));
        MaterialCardView c=card(true);
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(20),dp(20),dp(20),dp(20));
        TextView a=text("VI COUNTDOWN 4.0",22,white);a.setTypeface(null,1);l.addView(a);
        l.addView(text("Um countdown fã-made inspirado na energia neon de Vice City e no universo de Grand Theft Auto. Não é um produto oficial da Rockstar Games.",13,muted),margin(0,dp(8),0,0));
        l.addView(text("Data configurada: 19 de novembro de 2026.",13,white),margin(0,dp(12),0,0));
        l.addView(text("As mensagens do app são originais e foram escritas para evocar o clima da franquia sem reproduzir diálogos protegidos dos jogos.",12,muted),margin(0,dp(8),0,0));
        c.addView(l);content.addView(c);
        MaterialButton back=button("VOLTAR AO INÍCIO",true);back.setOnClickListener(v->showHome());content.addView(back,margin(0,dp(14),0,dp(20)));
    }

    private void section(String s){TextView t=text(s,11,cyan);t.setTypeface(null,1);content.addView(t,margin(0,dp(12),0,dp(8)));}

    private MaterialSwitch switcher(String title,String summary){
        MaterialSwitch s=new MaterialSwitch(this);s.setText(title+"\n"+summary);s.setTextColor(white);s.setTextSize(13);s.setPadding(dp(14),dp(10),dp(8),dp(10));s.setButtonTintList(null);return s;
    }
    private View settingRow(View v){MaterialCardView c=card(false);c.addView(v);return c;}

    private void pickTime(MaterialButton btn){
        TimePickerDialog d=new TimePickerDialog(this,(view,h,m)->{Prefs.time(this,h,m);btn.setText(String.format(Locale.getDefault(),"TODOS OS DIAS • %02d:%02d",h,m));NotificationScheduler.schedule(this);},Prefs.hour(this),Prefs.minute(this),true);
        d.show();
    }

    private void requestNotificationsIfNeeded(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIF_REQ);
    }

    private void startTicker(){
        if(tick!=null)handler.removeCallbacks(tick);
        tick=new Runnable(){public void run(){if(countdown!=null){long diff=TARGET_MILLIS-System.currentTimeMillis(); if(diff<=0){countdown.setText("É HOJE");subCountdown.setText("A contagem chegou ao destino.");}else{long sec=diff/1000;long days=sec/86400;sec%=86400;long hrs=sec/3600;sec%=3600;long min=sec/60;sec%=60;countdown.setText(String.format(Locale.getDefault(),"%03d",days));subCountdown.setText(String.format(Locale.getDefault(),"%02dh %02dm %02ds restantes",hrs,min,sec));}}handler.postDelayed(this,1000);}};
        handler.post(tick);
    }

    public static int daysRemaining(){
        long diff=TARGET_MILLIS-System.currentTimeMillis();
        return (int)Math.max(0,Math.ceil(diff/86400000.0));
    }

    private MaterialCardView card(boolean strong){
        MaterialCardView c=new MaterialCardView(this);
        c.setCardBackgroundColor(Color.parseColor(strong?"#E8171B31":"#CC121629"));
        c.setRadius(dp(strong?26:22));
        c.setStrokeWidth(dp(1)); c.setStrokeColor(strong?0x6643E8FF:0x332F4770);
        c.setCardElevation(dp(2));
        return c;
    }

    private MaterialButton button(String label,boolean primary){
        MaterialButton b=new MaterialButton(this);
        b.setText(label);b.setTextSize(11);b.setTypeface(null,1);b.setTextColor(white);
        b.setAllCaps(false);b.setPadding(dp(8),0,dp(8),0);
        b.setBackgroundResource(primary?R.drawable.button_primary:R.drawable.button_outline);
        return b;
    }

    private TextView text(String s,float size,int color){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;
    }

    private LinearLayout.LayoutParams margin(int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(l,t,r,b);return p;}
    private Space space(int w){Space s=new Space(this);s.setMinimumWidth(w);return s;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    @Override protected void onDestroy(){super.onDestroy();if(tick!=null)handler.removeCallbacks(tick);}
}