package com.vicountdown.studio;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String PREFS="vi_prefs";
    static final long LAUNCH_LOCAL=new GregorianCalendar(2026,Calendar.NOVEMBER,19,0,0,0).getTimeInMillis();
    Handler handler=new Handler(); Runnable ticker;
    int WHITE=Color.WHITE, MUTED=Color.rgb(201,194,216), PINK=Color.rgb(255,77,184), CYAN=Color.rgb(81,230,255), ORANGE=Color.rgb(255,154,85), PANEL=Color.rgb(26,16,44);
    TextView d,h,m,s,status;
    LinearLayout root;

    SharedPreferences prefs(){return getSharedPreferences(PREFS,MODE_PRIVATE);}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String t,float sz,int color,boolean bold){
        TextView x=new TextView(this); x.setText(t); x.setTextSize(sz); x.setTextColor(color); x.setGravity(Gravity.CENTER);
        x.setPadding(dp(8),dp(4),dp(8),dp(4)); if(bold)x.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return x;
    }
    GradientDrawable bg(int color,float radius,int stroke){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); if(stroke>0)g.setStroke(dp(1),stroke); return g;
    }
    Button button(String t,boolean primary){
        Button b=new Button(this); b.setText(t); b.setTextColor(WHITE); b.setTextSize(14); b.setAllCaps(false); b.setGravity(Gravity.CENTER);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setMinHeight(dp(52)); b.setPadding(dp(12),0,dp(12),0);
        b.setBackground(bg(primary?Color.rgb(95,42,125):Color.rgb(31,20,54),18,primary?Color.rgb(240,100,190):Color.rgb(85,67,115)));
        return b;
    }
    LinearLayout page(){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(dp(18),dp(12),dp(18),dp(22)); r.setBackgroundResource(com.vicountdown.studio.R.drawable.bg_gradient);
        return r;
    }
    TextView section(String t){TextView x=tv(t,13,CYAN,true); x.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); return x;}
    void space(LinearLayout r,int h){Space sp=new Space(this);r.addView(sp,new LinearLayout.LayoutParams(1,dp(h)));}

    @Override public void onCreate(Bundle b){
        super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(6,5,22));getWindow().setNavigationBarColor(Color.rgb(6,5,22));
        createChannel();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},22);
        showHome();
    }
    void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel("daily","VI Countdown",NotificationManager.IMPORTANCE_DEFAULT);
            c.setDescription("Notificações diárias e marcos do countdown");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    void showHome(){
        root=page();
        root.addView(tv("VI COUNTDOWN",12,PINK,true),new LinearLayout.LayoutParams(-1,dp(30)));
        root.addView(tv("GRAND THEFT AUTO",23,WHITE,true),new LinearLayout.LayoutParams(-1,dp(42)));
        TextView vi=tv("VI",92,WHITE,true); vi.setShadowLayer(dp(18),0,0,PINK); root.addView(vi,new LinearLayout.LayoutParams(-1,dp(106)));
        root.addView(tv("VICE CITY",16,CYAN,true),new LinearLayout.LayoutParams(-1,dp(30)));
        root.addView(tv("19 • NOV • 2026",12,MUTED,true),new LinearLayout.LayoutParams(-1,dp(30)));

        LinearLayout count=new LinearLayout(this); count.setGravity(Gravity.CENTER);
        TextView[] a=new TextView[4]; String[] labels={"DIAS","HORAS","MIN","SEG"};
        for(int i=0;i<4;i++){
            LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);c.setPadding(dp(5),dp(8),dp(5),dp(6));c.setBackground(bg(PANEL,20,Color.rgb(73,54,105)));
            a[i]=tv("00",25,WHITE,true); c.addView(a[i],new LinearLayout.LayoutParams(-1,dp(54)));c.addView(tv(labels[i],9,PINK,true),new LinearLayout.LayoutParams(-1,dp(25)));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(91),1);cp.setMargins(dp(3),0,dp(3),0);count.addView(c,cp);
        }
        d=a[0];h=a[1];m=a[2];s=a[3];root.addView(count,new LinearLayout.LayoutParams(-1,dp(102)));

        status=tv("A CIDADE ESTÁ ESPERANDO…",11,MUTED,true);root.addView(status,new LinearLayout.LayoutParams(-1,dp(38)));

        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setGravity(Gravity.CENTER);hero.setPadding(dp(15),dp(10),dp(15),dp(10));hero.setBackground(bg(Color.argb(210,27,16,49),24,Color.rgb(112,63,150)));
        hero.addView(tv("CONTAGEM REGRESSIVA ATIVA",10,CYAN,true));
        hero.addView(tv("O próximo capítulo começa em",13,MUTED,false));
        hero.addView(tv("19 NOVEMBRO 2026",20,ORANGE,true));
        root.addView(hero,new LinearLayout.LayoutParams(-1,dp(98)));space(root,12);

        Button notif=button("🔔   NOTIFICAÇÕES & MARCOS",true);notif.setOnClickListener(v->showSettings());root.addView(notif,new LinearLayout.LayoutParams(-1,dp(56)));
        space(root,8);
        Button msg=button("💬   CENTRAL DE FRASES",false);msg.setOnClickListener(v->showMessages());root.addView(msg,new LinearLayout.LayoutParams(-1,dp(56)));
        space(root,8);
        Button about=button("ⓘ   SOBRE O VI COUNTDOWN",false);about.setOnClickListener(v->showAbout());root.addView(about,new LinearLayout.LayoutParams(-1,dp(56)));

        setContentView(root);startTicker();
    }
    void startTicker(){if(ticker!=null)handler.removeCallbacks(ticker);ticker=()->{update();handler.postDelayed(ticker,1000);};handler.post(ticker);}
    void update(){
        long diff=LAUNCH_LOCAL-System.currentTimeMillis();if(diff<=0){d.setText("00");h.setText("00");m.setText("00");s.setText("00");status.setText("🚨 É HOJE. O COUNTDOWN TERMINOU.");return;}
        long q=diff/1000,dd=q/86400;q%=86400;long hh=q/3600;q%=3600;long mm=q/60,ss=q%60;
        d.setText(String.valueOf(dd));h.setText(String.format(Locale.US,"%02d",hh));m.setText(String.format(Locale.US,"%02d",mm));s.setText(String.format(Locale.US,"%02d",ss));
        status.setText(dd<=1?"🔥 FALTA MUITO POUCO.":dd<=7?"🚨 ÚLTIMA SEMANA.":dd<=30?"🌴 VICE CITY ESTÁ CADA VEZ MAIS PERTO.":"A CIDADE ESTÁ ESPERANDO…");
    }

    void showSettings(){
        ScrollView sv=new ScrollView(this);LinearLayout r=page();sv.addView(r);setContentView(sv);
        r.addView(tv("CONFIGURAÇÕES",28,WHITE,true),new LinearLayout.LayoutParams(-1,dp(62)));
        r.addView(tv("DEIXE O COUNTDOWN DO SEU JEITO",12,PINK,true),new LinearLayout.LayoutParams(-1,dp(35)));
        r.addView(section("🔔  NOTIFICAÇÕES"),new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout dailyCard=card();
        Switch daily=new Switch(this);daily.setText("Notificação diária");daily.setTextColor(WHITE);daily.setTextSize(16);daily.setChecked(prefs().getBoolean("daily",true));
        dailyCard.addView(daily,new LinearLayout.LayoutParams(-1,dp(58)));
        TextView time=tv(timeLabel(),15,MUTED,true);time.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);dailyCard.addView(time,new LinearLayout.LayoutParams(-1,dp(48)));
        Button pick=button("🕘  Alterar horário",false);pick.setOnClickListener(v->pickTime(time));dailyCard.addView(pick,new LinearLayout.LayoutParams(-1,dp(52)));
        Button test=button("🔔  Testar agora",false);test.setOnClickListener(v->testNotification());dailyCard.addView(test,new LinearLayout.LayoutParams(-1,dp(52)));
        r.addView(dailyCard,new LinearLayout.LayoutParams(-1,dp(222)));space(r,10);

        r.addView(section("🎯  MARCOS DO LANÇAMENTO"),new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout marks=card();String[] ms={"100 dias","50 dias","30 dias","10 dias","7 dias","3 dias","1 dia","Lançamento"};
        for(String x:ms){CheckBox c=new CheckBox(this);c.setText(x);c.setTextColor(MUTED);c.setTextSize(14);c.setChecked(prefs().getBoolean("mark_"+x,false));c.setMinHeight(dp(44));c.setOnCheckedChangeListener((v,ch)->prefs().edit().putBoolean("mark_"+x,ch).apply());marks.addView(c);}
        r.addView(marks,new LinearLayout.LayoutParams(-1,dp(8*44+18)));space(r,10);

        r.addView(section("💬  ESTILO DAS FRASES"),new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout style=card();
        RadioGroup rg=new RadioGroup(this);rg.setOrientation(RadioGroup.VERTICAL);
        String[] modes={"Aleatórias — recomendado","GTA / Vice City","Motivação / countdown","Humor / provocação"};
        String saved=prefs().getString("mode","Aleatórias — recomendado");
        for(String x:modes){RadioButton rb=new RadioButton(this);rb.setText(x);rb.setTextColor(MUTED);rb.setTextSize(14);rb.setMinHeight(dp(44));rb.setChecked(saved.equals(x));rb.setOnClickListener(v->prefs().edit().putString("mode",((RadioButton)v).getText().toString()).apply());rg.addView(rb);}
        style.addView(rg,new LinearLayout.LayoutParams(-1,dp(4*44+8)));r.addView(style,new LinearLayout.LayoutParams(-1,dp(190)));space(r,10);

        r.addView(section("🎨  APARÊNCIA"),new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout appearance=card();appearance.addView(tv("Tema atual",14,WHITE,true),new LinearLayout.LayoutParams(-1,dp(35)));
        appearance.addView(tv("Neon Sunset • rosa • roxo • azul • laranja",13,MUTED,false),new LinearLayout.LayoutParams(-1,dp(38)));
        appearance.addView(tv("Interface pensada para manter contraste, espaçamento e leitura confortáveis.",12,MUTED,false),new LinearLayout.LayoutParams(-1,dp(55)));
        r.addView(appearance,new LinearLayout.LayoutParams(-1,dp(145)));space(r,14);

        Button save=button("✓   SALVAR & ATIVAR",true);save.setOnClickListener(v->{prefs().edit().putBoolean("daily",daily.isChecked()).apply();schedule();Toast.makeText(this,"Configurações salvas.",Toast.LENGTH_SHORT).show();});r.addView(save,new LinearLayout.LayoutParams(-1,dp(58)));
        space(r,8);Button back=button("←   VOLTAR",false);back.setOnClickListener(v->showHome());r.addView(back,new LinearLayout.LayoutParams(-1,dp(56)));
    }
    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(14),dp(8),dp(14),dp(8));c.setBackground(bg(Color.rgb(24,15,42),22,Color.rgb(66,50,95)));return c;}
    String timeLabel(){return String.format(Locale.US,"Todos os dias às %02d:%02d",prefs().getInt("hour",9),prefs().getInt("minute",0));}
    void pickTime(TextView label){new TimePickerDialog(this,(v,hh,mm)->{prefs().edit().putInt("hour",hh).putInt("minute",mm).apply();label.setText(timeLabel());},prefs().getInt("hour",9),prefs().getInt("minute",0),true).show();}
    void schedule(){
        Intent i=new Intent(this,DailyNotificationReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,700,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        if(!prefs().getBoolean("daily",true)){am.cancel(pi);return;}
        Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,prefs().getInt("hour",9));c.set(Calendar.MINUTE,prefs().getInt("minute",0));c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
    }
    void testNotification(){sendNotification("🔔 Teste do VI Countdown: a cidade está esperando.");}
    void sendNotification(String msg){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED){Toast.makeText(this,"Ative as notificações do app para testar.",Toast.LENGTH_LONG).show();return;}
        android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,"daily"):new android.app.Notification.Builder(this);
        Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,701,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(com.vicountdown.studio.R.drawable.app_icon_foreground).setContentTitle("VI COUNTDOWN").setContentText(msg).setStyle(new android.app.Notification.BigTextStyle().bigText(msg)).setAutoCancel(true).setContentIntent(pi);nm.notify(701,b.build());
    }

    void showMessages(){
        ScrollView sv=new ScrollView(this);LinearLayout r=page();sv.addView(r);setContentView(sv);
        r.addView(tv("CENTRAL DE FRASES",28,WHITE,true),new LinearLayout.LayoutParams(-1,dp(62)));
        r.addView(tv("Mensagens originais para você receber durante a espera",12,PINK,true),new LinearLayout.LayoutParams(-1,dp(40)));
        String[] msgs=Messages.ALL;
        for(int i=0;i<msgs.length;i++){LinearLayout c=card();TextView n=tv(String.format(Locale.US,"%03d",i+1),10,CYAN,true);n.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);c.addView(n,new LinearLayout.LayoutParams(-1,dp(25)));TextView q=tv("“"+msgs[i]+"”",14,MUTED,false);q.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);c.addView(q,new LinearLayout.LayoutParams(-1,dp(60)));r.addView(c,new LinearLayout.LayoutParams(-1,dp(92)));space(r,6);}
        Button back=button("←   VOLTAR",false);back.setOnClickListener(v->showHome());r.addView(back,new LinearLayout.LayoutParams(-1,dp(56)));
    }
    void showAbout(){
        ScrollView sv=new ScrollView(this);LinearLayout r=page();sv.addView(r);setContentView(sv);
        r.addView(tv("SOBRE O APP",28,WHITE,true),new LinearLayout.LayoutParams(-1,dp(64)));
        LinearLayout c=card();c.addView(tv("VI COUNTDOWN",25,PINK,true),new LinearLayout.LayoutParams(-1,dp(55)));
        TextView t=tv("Um aplicativo independente para acompanhar a chegada de GTA VI.\n\nInterface neon original, countdown em tempo real, notificações diárias, marcos e central de frases.\n\nNão é um aplicativo oficial nem afiliado à Rockstar Games.",14,MUTED,false);t.setGravity(Gravity.LEFT|Gravity.TOP);c.addView(t,new LinearLayout.LayoutParams(-1,dp(230)));r.addView(c,new LinearLayout.LayoutParams(-1,dp(310)));space(r,14);
        Button back=button("←   VOLTAR",false);back.setOnClickListener(v->showHome());r.addView(back,new LinearLayout.LayoutParams(-1,dp(56)));
    }
    @Override protected void onResume(){super.onResume();if(prefs().getBoolean("daily",true))schedule();}
    @Override protected void onDestroy(){if(ticker!=null)handler.removeCallbacks(ticker);super.onDestroy();}
}
