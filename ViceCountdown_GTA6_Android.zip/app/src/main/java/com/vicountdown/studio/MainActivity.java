package com.vicountdown.studio;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    public static final long TARGET_MILLIS = new GregorianCalendar(2026, Calendar.NOVEMBER, 19, 0, 0, 0).getTimeInMillis();
    private static final int NOTIF_REQ = 701;
    private LinearLayout content;
    private TextView daysView, hoursView, minutesView, secondsView, progressLabel;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable tick;
    private final int bg = Color.rgb(7, 9, 18);
    private final int card = Color.rgb(18, 21, 36);
    private final int white = Color.rgb(247, 247, 250);
    private final int muted = Color.rgb(151, 156, 177);
    private final int pink = Color.rgb(255, 91, 177);
    private final int cyan = Color.rgb(69, 216, 235);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        DailyNotificationReceiver.createChannel(this);
        buildShell();
        requestNotificationsIfNeeded();
        NotificationScheduler.schedule(this);
    }

    private void buildShell() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(bg);
        root.addView(new NeonBackdropView(this), new FrameLayout.LayoutParams(-1, -1));

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(12), dp(20), dp(18));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(content);
        shell.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        shell.addView(navBar(), new LinearLayout.LayoutParams(-1, dp(64)));
        root.addView(shell, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        showHome();
    }

    private View navBar() {
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(18), dp(6), dp(18), dp(7));
        GradientDrawable bgNav = new GradientDrawable();
        bgNav.setColor(0xF20B0E19);
        bgNav.setStroke(dp(1), 0x182D3954);
        nav.setBackground(bgNav);

        String[] labels = {"INÍCIO", "MENSAGENS", "AJUSTES"};
        for (int i = 0; i < 3; i++) {
            final int tab = i;
            TextView t = text(labels[i], 10, i == 0 ? white : muted);
            t.setGravity(Gravity.CENTER);
            t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            t.setLetterSpacing(.08f);
            t.setOnClickListener(v -> { if (tab == 0) showHome(); else if (tab == 1) showMessages(); else showSettings(); });
            nav.addView(t, new LinearLayout.LayoutParams(0, -1, 1));
        }
        return nav;
    }

    private void showHome() {
        content.removeAllViews();

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("VI", 18, white);
        logo.setGravity(Gravity.CENTER);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable logoBg = new GradientDrawable();
        logoBg.setShape(GradientDrawable.OVAL);
        logoBg.setColor(0xFF1A2033);
        logoBg.setStroke(dp(1), 0x5545D8EB);
        logo.setBackground(logoBg);
        header.addView(logo, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout titles = column(0, 0, 0, 0);
        TextView name = text("VI COUNTDOWN", 13, white);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titles.addView(name);
        TextView status = text("LEONIDA • 19 NOV 2026", 10, muted);
        status.setLetterSpacing(.06f);
        titles.addView(status, margin(0, dp(2), 0, 0));
        header.addView(titles, margin(dp(12), 0, 0, 0));
        content.addView(header, margin(0, dp(6), 0, dp(22)));

        TextView eyebrow = text("CONTAGEM REGRESSIVA", 10, cyan);
        eyebrow.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        eyebrow.setLetterSpacing(.12f);
        content.addView(eyebrow, margin(0, 0, 0, dp(8)));

        LinearLayout hero = card();
        LinearLayout heroInner = column(dp(18), dp(22), dp(18), dp(20));
        TextView title = text("O próximo capítulo começa em", 14, muted);
        title.setGravity(Gravity.CENTER);
        heroInner.addView(title);

        LinearLayout numbers = new LinearLayout(this);
        numbers.setGravity(Gravity.CENTER);
        numbers.setPadding(0, dp(12), 0, dp(6));
        daysView = number("000"); hoursView = number("00"); minutesView = number("00"); secondsView = number("00");
        numbers.addView(timeUnit(daysView, "DIAS"), new LinearLayout.LayoutParams(0, -2, 1));
        numbers.addView(separator(), new LinearLayout.LayoutParams(dp(1), dp(50)));
        numbers.addView(timeUnit(hoursView, "HORAS"), new LinearLayout.LayoutParams(0, -2, 1));
        numbers.addView(separator(), new LinearLayout.LayoutParams(dp(1), dp(50)));
        numbers.addView(timeUnit(minutesView, "MIN"), new LinearLayout.LayoutParams(0, -2, 1));
        numbers.addView(separator(), new LinearLayout.LayoutParams(dp(1), dp(50)));
        numbers.addView(timeUnit(secondsView, "SEG"), new LinearLayout.LayoutParams(0, -2, 1));
        heroInner.addView(numbers);

        progressLabel = text("", 10, muted);
        progressLabel.setGravity(Gravity.CENTER);
        heroInner.addView(progressLabel, margin(0, dp(10), 0, dp(7)));
        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(progressPercent());
        if (Build.VERSION.SDK_INT >= 21) progress.setProgressTintList(android.content.res.ColorStateList.valueOf(cyan));
        heroInner.addView(progress, new LinearLayout.LayoutParams(-1, dp(4)));
        hero.addView(heroInner);
        content.addView(hero, margin(0, 0, 0, dp(16)));

        LinearLayout message = card();
        LinearLayout mi = column(dp(18), dp(17), dp(18), dp(17));
        LinearLayout msgHead = new LinearLayout(this);
        msgHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView dot = text("•", 22, pink);
        dot.setGravity(Gravity.CENTER);
        msgHead.addView(dot, new LinearLayout.LayoutParams(dp(20), dp(20)));
        TextView mh = text("MENSAGEM DE HOJE", 10, white);
        mh.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        mh.setLetterSpacing(.1f);
        msgHead.addView(mh, margin(dp(7), 0, 0, 0));
        mi.addView(msgHead);
        TextView body = text(Messages.messageForDay(Math.max(0, daysRemaining())), 16, white);
        body.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        mi.addView(body, margin(0, dp(11), 0, dp(7)));
        TextView hint = text("Uma frase nova a cada dia.", 11, muted);
        mi.addView(hint);
        message.addView(mi);
        content.addView(message, margin(0, 0, 0, dp(16)));

        LinearLayout actions = new LinearLayout(this);
        Button messages = button("VER MENSAGENS", false);
        messages.setOnClickListener(v -> showMessages());
        Button settings = button("NOTIFICAÇÕES", true);
        settings.setOnClickListener(v -> showSettings());
        actions.addView(messages, new LinearLayout.LayoutParams(0, dp(48), 1));
        actions.addView(space(dp(10)), new LinearLayout.LayoutParams(dp(10), 1));
        actions.addView(settings, new LinearLayout.LayoutParams(0, dp(48), 1));
        content.addView(actions, margin(0, 0, 0, dp(18)));

        TextView foot = text("FAN-MADE • NÃO OFICIAL", 9, muted);
        foot.setGravity(Gravity.CENTER);
        foot.setLetterSpacing(.08f);
        content.addView(foot, margin(0, 0, 0, dp(14)));
        startTicker();
    }

    private View timeUnit(TextView value, String label) {
        LinearLayout box = column(0, 0, 0, 0);
        value.setGravity(Gravity.CENTER);
        box.addView(value);
        TextView l = text(label, 8, muted);
        l.setGravity(Gravity.CENTER);
        l.setLetterSpacing(.12f);
        box.addView(l, margin(0, dp(2), 0, 0));
        return box;
    }

    private TextView number(String s) {
        TextView t = text(s, 25, white);
        t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    private View separator() {
        View v = new View(this);
        v.setBackgroundColor(0x24384659);
        return v;
    }

    private void showMessages() {
        content.removeAllViews();
        pageTitle("MENSAGENS", "Frases originais para acompanhar a contagem.");

        LinearLayout featured = card();
        LinearLayout fi = column(dp(18), dp(18), dp(18), dp(18));
        TextView tag = text("DESTAQUE DE HOJE", 9, cyan);
        tag.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tag.setLetterSpacing(.1f);
        fi.addView(tag);
        TextView quote = text(Messages.messageForDay(Math.max(0, daysRemaining())), 18, white);
        quote.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        fi.addView(quote, margin(0, dp(10), 0, 0));
        featured.addView(fi);
        content.addView(featured, margin(0, 0, 0, dp(18)));

        TextView archive = text("ARQUIVO RECENTE", 10, muted);
        archive.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        archive.setLetterSpacing(.1f);
        content.addView(archive, margin(0, 0, 0, dp(9)));

        int total = Math.min(10, Messages.ALL.length);
        for (int i = 0; i < total; i++) {
            LinearLayout row = card();
            TextView n = text(String.format(Locale.getDefault(), "%02d", i + 1), 10, cyan);
            n.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(16), dp(13), dp(16), dp(13));
            row.addView(n, new LinearLayout.LayoutParams(dp(28), -2));
            TextView q = text(Messages.ALL[i], 13, white);
            row.addView(q, new LinearLayout.LayoutParams(0, -2, 1));
            content.addView(row, margin(0, 0, 0, dp(7)));
        }
        TextView note = text("O arquivo completo pode crescer sem sobrecarregar a tela inicial.", 10, muted);
        note.setGravity(Gravity.CENTER);
        content.addView(note, margin(0, dp(10), 0, dp(18)));
    }

    private void showSettings() {
        content.removeAllViews();
        pageTitle("AJUSTES", "Tudo importante, sem excesso de controles.");

        TextView h1 = section("NOTIFICAÇÕES");
        content.addView(h1, margin(0, dp(4), 0, dp(8)));
        LinearLayout notif = card();
        LinearLayout ni = column(dp(16), dp(14), dp(16), dp(14));
        Switch sw = switcher("Mensagem diária", "Uma frase diferente todos os dias.");
        sw.setChecked(Prefs.enabled(this));
        sw.setOnCheckedChangeListener((b, v) -> { Prefs.enabled(this, v); NotificationScheduler.schedule(this); });
        ni.addView(sw);
        Button time = button(String.format(Locale.getDefault(), "HORÁRIO • %02d:%02d", Prefs.hour(this), Prefs.minute(this)), false);
        time.setOnClickListener(v -> pickTime(time));
        ni.addView(time, margin(0, dp(9), 0, dp(8)));
        Button test = button("TESTAR NOTIFICAÇÃO", true);
        test.setOnClickListener(v -> {
            DailyNotificationReceiver.createChannel(this);
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) { requestNotificationsIfNeeded(); return; }
            DailyNotificationReceiver.show(this);
            Toast.makeText(this, "Notificação enviada.", Toast.LENGTH_SHORT).show();
        });
        ni.addView(test);
        notif.addView(ni);
        content.addView(notif, margin(0, 0, 0, dp(16)));

        content.addView(section("EXPERIÊNCIA"), margin(0, 0, 0, dp(8)));
        LinearLayout exp = card();
        LinearLayout ei = column(dp(16), dp(5), dp(16), dp(5));
        Switch sound = switcher("Som", "Som padrão da notificação.");
        sound.setChecked(Prefs.sound(this));
        sound.setOnCheckedChangeListener((b, v) -> Prefs.sound(this, v));
        ei.addView(sound);
        Switch vib = switcher("Vibração", "Vibração curta ao notificar.");
        vib.setChecked(Prefs.vibration(this));
        vib.setOnCheckedChangeListener((b, v) -> Prefs.vibration(this, v));
        ei.addView(vib);
        Switch milestones = switcher("Marcos", "Mensagens especiais em datas importantes.");
        milestones.setChecked(Prefs.milestones(this));
        milestones.setOnCheckedChangeListener((b, v) -> Prefs.milestones(this, v));
        ei.addView(milestones);
        exp.addView(ei);
        content.addView(exp, margin(0, 0, 0, dp(16)));

        content.addView(section("ESTILO"), margin(0, 0, 0, dp(8)));
        LinearLayout style = card();
        RadioGroup rg = new RadioGroup(this);
        String[] labels = {"Mix Vice City / Leonida", "Cidade / mapa", "Legado GTA", "Motivação / countdown"};
        String[] vals = {"mix", "vi", "legacy", "motivation"};
        String saved = Prefs.style(this);
        for (int i = 0; i < labels.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(labels[i]); rb.setTextColor(white); rb.setTextSize(13); rb.setTag(vals[i]); rb.setPadding(0, dp(7), 0, dp(7));
            if (saved.equals(vals[i])) rb.setChecked(true);
            rg.addView(rb);
        }
        rg.setOnCheckedChangeListener((g, id) -> { RadioButton rb = g.findViewById(id); if (rb != null) Prefs.style(this, String.valueOf(rb.getTag())); });
        style.addView(rg);
        content.addView(style, margin(0, 0, 0, dp(16)));

        Button about = button("SOBRE O APP", false);
        about.setOnClickListener(v -> showAbout());
        content.addView(about, margin(0, 0, 0, dp(20)));
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("VI COUNTDOWN")
                .setMessage("Countdown fã-made inspirado na estética neon de Vice City.\n\nData configurada: 19 de novembro de 2026.\n\nNão é um produto oficial da Rockstar Games. As mensagens são originais.")
                .setPositiveButton("OK", null)
                .show();
    }

    private TextView section(String s) {
        TextView t = text(s, 9, cyan);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLetterSpacing(.12f);
        return t;
    }

    private void pageTitle(String title, String subtitle) {
        TextView t = text(title, 26, white);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        content.addView(t, margin(0, dp(7), 0, dp(4)));
        content.addView(text(subtitle, 12, muted), margin(0, 0, 0, dp(18)));
    }

    private Switch switcher(String title, String summary) {
        Switch s = new Switch(this);
        s.setText(title + "\n" + summary);
        s.setTextColor(white);
        s.setTextSize(13);
        s.setPadding(0, dp(8), 0, dp(8));
        return s;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xE8131726);
        g.setCornerRadius(dp(18));
        g.setStroke(dp(1), 0x1F4B5875);
        l.setBackground(g);
        return l;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(10);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(white);
        b.setAllCaps(false);
        b.setLetterSpacing(.05f);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0); b.setMinWidth(0);
        b.setPadding(dp(8), 0, dp(8), 0);
        GradientDrawable g = new GradientDrawable();
        if (primary) {
            g.setColor(0xFFE84D9F);
            g.setStroke(dp(1), 0x55FF9FD0);
        } else {
            g.setColor(0x26141B2C);
            g.setStroke(dp(1), 0x33485D7A);
        }
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        return b;
    }

    private void pickTime(Button btn) {
        TimePickerDialog d = new TimePickerDialog(this, (view, h, m) -> {
            Prefs.time(this, h, m);
            btn.setText(String.format(Locale.getDefault(), "HORÁRIO • %02d:%02d", h, m));
            NotificationScheduler.schedule(this);
        }, Prefs.hour(this), Prefs.minute(this), true);
        d.show();
    }

    private void requestNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQ);
    }

    private void startTicker() {
        if (tick != null) handler.removeCallbacks(tick);
        tick = () -> {
            long diff = TARGET_MILLIS - System.currentTimeMillis();
            if (diff <= 0) {
                daysView.setText("000"); hoursView.setText("00"); minutesView.setText("00"); secondsView.setText("00");
                progressLabel.setText("É HOJE • contagem concluída");
            } else {
                long sec = diff / 1000;
                long days = sec / 86400; sec %= 86400;
                long hrs = sec / 3600; sec %= 3600;
                long min = sec / 60; sec %= 60;
                daysView.setText(String.format(Locale.getDefault(), "%03d", days));
                hoursView.setText(String.format(Locale.getDefault(), "%02d", hrs));
                minutesView.setText(String.format(Locale.getDefault(), "%02d", min));
                secondsView.setText(String.format(Locale.getDefault(), "%02d", sec));
                progressLabel.setText(days + " dias restantes • atualização em tempo real");
            }
            handler.postDelayed(tick, 1000);
        };
        handler.post(tick);
    }

    public static int daysRemaining() {
        long diff = TARGET_MILLIS - System.currentTimeMillis();
        return (int) Math.max(0, Math.ceil(diff / 86400000.0));
    }

    private int progressPercent() {
        long now = System.currentTimeMillis();
        long start = new GregorianCalendar(2025, Calendar.MAY, 26).getTimeInMillis();
        if (now <= start) return 0;
        if (now >= TARGET_MILLIS) return 100;
        return (int) Math.max(0, Math.min(100, ((now - start) * 100.0) / (TARGET_MILLIS - start)));
    }

    private LinearLayout column(int l, int t, int r, int b) { LinearLayout x = new LinearLayout(this); x.setOrientation(LinearLayout.VERTICAL); x.setPadding(l, t, r, b); return x; }
    private TextView text(String s, float size, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    private LinearLayout.LayoutParams margin(int l, int t, int r, int b) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(l, t, r, b); return p; }
    private Space space(int width) { Space s = new Space(this); s.setMinimumWidth(width); return s; }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onDestroy() { super.onDestroy(); if (tick != null) handler.removeCallbacks(tick); }
}
