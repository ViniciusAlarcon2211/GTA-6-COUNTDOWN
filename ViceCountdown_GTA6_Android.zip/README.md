# VI Countdown — Final
Versão visual focada em uma experiência neon/pôr-do-sol original, com contador, configurações organizadas, notificações diárias, marcos, central de frases e ícone próprio.

Data configurada: 19/11/2026.
Não é um aplicativo oficial nem afiliado à Rockstar Games.

O projeto é Android nativo e não depende de bibliotecas externas de UI.
O workflow GitHub pode extrair este ZIP e executar `gradle assembleDebug`.
Nome esperado pelo workflow do usuário: `ViceCountdown_GTA6_Android.zip`.
