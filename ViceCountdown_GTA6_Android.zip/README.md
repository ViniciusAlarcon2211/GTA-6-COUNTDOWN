
# VI Countdown Studio 4.0

Projeto Android fã-made de countdown para Grand Theft Auto VI.

## O que foi reconstruído

- Interface neon noturna inspirada na atmosfera de Vice City, sem copiar a identidade visual oficial.
- Fundo animado com skyline, palmeiras, pôr do sol, estrada em perspectiva e scanlines.
- Countdown principal em dias + horas + minutos + segundos.
- Cards, chips, hierarquia visual e navegação inferior inspirados em padrões modernos do Material 3.
- Central de frases com mensagens originais para evitar reprodução de diálogos protegidos dos jogos.
- Notificações diárias com uma mensagem diferente por dia.
- Horário configurável.
- Som e vibração configuráveis.
- Marcos especiais.
- Reschedule após reinicialização do aparelho.
- Pedido de permissão de notificações no Android 13+.
- Ícone original fã-made.
- Configurado para 19/11/2026, data anunciada oficialmente pela Rockstar Games.

## Build

O workflow existente do repositório pode usar este ZIP com Gradle 8.9.
Não existe Gradle Wrapper de propósito: o GitHub Actions instala o Gradle.

## Observação

Este aplicativo não é afiliado, patrocinado ou endossado pela Rockstar Games.
