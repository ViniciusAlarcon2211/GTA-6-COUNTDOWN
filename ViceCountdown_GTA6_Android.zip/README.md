# VI Countdown 2.0

Aplicativo Android independente de contagem regressiva para 19/11/2026.

Inclui:
- interface neon inspirada na estética de Vice City;
- contador em tempo real;
- configurações;
- notificações diárias com horário configurável;
- mensagens originais;
- marcos de contagem;
- ícone próprio VI;
- tela sobre o aplicativo.

Não é um aplicativo oficial nem afiliado à Rockstar Games.

Para o workflow usado neste projeto, o ZIP deve permanecer com o nome:
ViceCountdown_GTA6_Android.zip
